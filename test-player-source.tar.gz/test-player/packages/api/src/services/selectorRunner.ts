// ================================================================
// THE SELECTOR — Weekly Runner
// Runs nightly (or on demand).
// Pulls assessment + EPOS + operational data for each team member,
// runs the scoring engine, writes results back to selector_scores,
// updates team_members.selector_tier/status, generates AI narratives.
// ================================================================

import { db } from '../config/database.js';
import { env } from '../config/env.js';
import {
  runSelector,
  rankMembers,
  venueAggregateScore,
  type AssessmentInput,
  type EposInput,
  type OperationalInput,
} from './selector.js';
import Anthropic from '@anthropic-ai/sdk';
import { randomUUID } from 'crypto';

type Row = Record<string, unknown>;

/**
 * Run The Selector for all venues for a given week.
 * weekEnding defaults to the most recent Sunday.
 */
export async function runSelectorForWeek(weekEnding?: string): Promise<{
  membersScored: number;
  venuesProcessed: number;
  weekEnding: string;
}> {
  const week = weekEnding ?? getMostRecentSunday();

  console.log(`[The Selector] Running for week ending ${week}...`);

  const venues = await db.query<{ id: string; name: string }>(
    `SELECT id, name FROM venues WHERE is_active = true ORDER BY name`,
  );

  let totalMembersScored = 0;

  for (const venue of venues.rows) {
    const count = await runSelectorForVenue(venue.id, week);
    totalMembersScored += count;
    console.log(`[The Selector] ${venue.name}: ${count} members scored`);
  }

  // Update league positions across all venues
  await updateLeaguePositions(week);

  console.log(`[The Selector] Complete. ${totalMembersScored} members scored across ${venues.rows.length} venues.`);

  return {
    membersScored: totalMembersScored,
    venuesProcessed: venues.rows.length,
    weekEnding: week,
  };
}

async function runSelectorForVenue(venueId: string, weekEnding: string): Promise<number> {
  const members = await db.query<{ id: string; first_name: string; last_name: string; selector_score: string | null }>(
    `SELECT id, first_name, last_name, selector_score
     FROM team_members WHERE venue_id = $1 AND is_active = true`,
    [venueId],
  );

  const memberResults: Array<{ memberId: string; totalScore: number }> = [];

  for (const member of members.rows) {
    const result = await scoreMember(member.id, venueId, weekEnding);
    if (result) {
      memberResults.push({ memberId: member.id, totalScore: result.totalScore });
    }
  }

  // Rank within venue
  const ranked = rankMembers(memberResults);
  for (const { memberId, rankInVenue } of ranked) {
    await db.query(
      `UPDATE selector_scores SET rank_in_venue = $1
       WHERE team_member_id = $2 AND week_ending = $3`,
      [rankInVenue, memberId, weekEnding],
    );
  }

  // Venue aggregate score
  if (memberResults.length > 0) {
    const avgScore = venueAggregateScore(memberResults.map(m => m.totalScore));

    const prevVenue = await db.query<{ total_score: string }>(
      `SELECT total_score FROM venue_scores
       WHERE venue_id = $1 AND week_ending < $2
       ORDER BY week_ending DESC LIMIT 1`,
      [venueId, weekEnding],
    );
    const prevScore = prevVenue.rows[0] ? parseFloat(prevVenue.rows[0].total_score) : null;

    await db.query(
      `INSERT INTO venue_scores (id, venue_id, week_ending, total_score, previous_score, score_change, members_scored)
       VALUES ($1,$2,$3,$4,$5,$6,$7)
       ON CONFLICT (venue_id, week_ending) DO UPDATE
       SET total_score = EXCLUDED.total_score, previous_score = EXCLUDED.previous_score,
           score_change = EXCLUDED.score_change, members_scored = EXCLUDED.members_scored`,
      [randomUUID(), venueId, weekEnding, avgScore, prevScore,
       prevScore != null ? round2(avgScore - prevScore) : null,
       memberResults.length],
    );
  }

  return memberResults.length;
}

async function scoreMember(
  memberId: string,
  venueId: string,
  weekEnding: string,
): Promise<{ totalScore: number } | null> {
  // Fetch assessment
  const assessmentRow = await db.query<Row>(
    `SELECT product_confidence, guest_warmth, table_reading, values_alignment,
            coaching_tier, coaching_note, dont_say_flags
     FROM manager_assessments
     WHERE team_member_id = $1 AND week_ending = $2`,
    [memberId, weekEnding],
  );

  const aRow = assessmentRow.rows[0];
  const assessment: AssessmentInput | null = aRow ? {
    productConfidence: aRow['product_confidence'] as number,
    guestWarmth:       aRow['guest_warmth'] as number,
    tableReading:      aRow['table_reading'] as number,
    valuesAlignment:   aRow['values_alignment'] as number,
    coachingTier:      aRow['coaching_tier'] as AssessmentInput['coachingTier'],
  } : null;

  // Fetch EPOS
  const eposRow = await db.query<Row>(
    `SELECT food_attachment_rate, dessert_conversion_rate, coffee_conversion_rate,
            wine_attachment_rate, cover_value_index
     FROM epos_metrics
     WHERE team_member_id = $1 AND week_ending = $2`,
    [memberId, weekEnding],
  );

  const eRow = eposRow.rows[0];
  const epos: EposInput | null = eRow ? {
    foodAttachmentRate:    eRow['food_attachment_rate'] as number | null,
    dessertConversionRate: eRow['dessert_conversion_rate'] as number | null,
    coffeeConversionRate:  eRow['coffee_conversion_rate'] as number | null,
    wineAttachmentRate:    eRow['wine_attachment_rate'] as number | null,
    coverValueIndex:       eRow['cover_value_index'] as number | null,
  } : null;

  // Fetch operational
  const opsRow = await db.query<Row>(
    `SELECT rota_adherence_pct, trail_score
     FROM operational_metrics
     WHERE team_member_id = $1 AND week_ending = $2`,
    [memberId, weekEnding],
  );

  const oRow = opsRow.rows[0];
  const operational: OperationalInput | null = oRow ? {
    rotaAdherencePct: oRow['rota_adherence_pct'] as number | null,
    trailScore:       oRow['trail_score'] as number | null,
  } : null;

  // Nothing to score
  if (!assessment && !epos && !operational) return null;

  // Run The Selector
  const result = runSelector({ assessment, epos, operational });

  // Get previous score
  const prevRow = await db.query<{ total_score: string }>(
    `SELECT total_score FROM selector_scores
     WHERE team_member_id = $1 AND week_ending < $2
     ORDER BY week_ending DESC LIMIT 1`,
    [memberId, weekEnding],
  );
  const prevScore = prevRow.rows[0] ? parseFloat(prevRow.rows[0].total_score) : null;

  // Write score
  await db.query(
    `INSERT INTO selector_scores
       (id, team_member_id, venue_id, week_ending,
        total_score, previous_score, score_change,
        assessment_score, epos_score, operational_score,
        tier, programme_status, score_breakdown)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13)
     ON CONFLICT (team_member_id, week_ending) DO UPDATE
     SET total_score = EXCLUDED.total_score,
         previous_score = EXCLUDED.previous_score,
         score_change = EXCLUDED.score_change,
         assessment_score = EXCLUDED.assessment_score,
         epos_score = EXCLUDED.epos_score,
         operational_score = EXCLUDED.operational_score,
         tier = EXCLUDED.tier,
         programme_status = EXCLUDED.programme_status,
         score_breakdown = EXCLUDED.score_breakdown`,
    [
      randomUUID(), memberId, venueId, weekEnding,
      result.totalScore,
      prevScore,
      prevScore != null ? round2(result.totalScore - prevScore) : null,
      result.assessmentScore,
      result.eposScore,
      result.operationalScore,
      result.tier,
      result.programmeStatus,
      JSON.stringify(result.breakdown),
    ],
  );

  // Update team_member denormalised fields for fast display queries
  await db.query(
    `UPDATE team_members
     SET selector_tier = $1, selector_status = $2, selector_score = $3, selector_updated_at = NOW()
     WHERE id = $4`,
    [result.tier, result.programmeStatus, result.totalScore, memberId],
  );

  // Generate AI coaching narrative (async, non-blocking)
  if (env.ANTHROPIC_API_KEY && aRow?.['coaching_note']) {
    void generateNarrative(memberId, venueId, weekEnding, result, aRow);
  }

  return { totalScore: result.totalScore };
}

async function generateNarrative(
  memberId: string,
  venueId: string,
  weekEnding: string,
  result: Awaited<ReturnType<typeof runSelector>>,
  assessmentRow: Row,
): Promise<void> {
  try {
    const memberRow = await db.query<{ first_name: string; last_name: string; role: string }>(
      `SELECT first_name, last_name, role FROM team_members WHERE id = $1`,
      [memberId],
    );
    const member = memberRow.rows[0];
    if (!member) return;

    const client = new Anthropic({ apiKey: env.ANTHROPIC_API_KEY });

    const prompt = `You are generating a coaching assessment for a Cat & Wickets hospitality team member as The Selector.

Team member: ${member.first_name} ${member.last_name} (${member.role ?? 'team member'})
Week ending: ${weekEnding}

Scores:
- Overall: ${result.totalScore}/100
- Manager assessment: ${result.assessmentScore}/100 (40% weight)
- EPOS signals: ${result.eposScore}/100 (40% weight)  
- Operational: ${result.operationalScore}/100 (20% weight)

The Selector has assigned tier: ${result.tier.toUpperCase().replace('-', ' ')}
Programme status: ${result.programmeStatus.replace('-', ' ')}

Manager's coaching note: "${assessmentRow['coaching_note'] as string}"
${assessmentRow['dont_say_flags'] ? `Phrases to address: ${(assessmentRow['dont_say_flags'] as string[]).join(', ')}` : ''}

Coaching tier framework:
- Don't Say: phrases/habits that weaken the brand
- Have To: non-negotiable minimum standards
- Should Say: strong, knowledgeable Cat & Wickets server
- Could Say: Test Player standard — highest level of hospitality craft

Write a concise coaching assessment (3-4 paragraphs) in The Selector's voice. Start with what's working. Be specific about the development opportunity. Frame everything developmentally — not punitive. Reference the coaching tier framework. End with one concrete action for the manager to take in their next one-to-one. Do not use bullet points.`;

    const response = await client.messages.create({
      model: 'claude-sonnet-4-20250514',
      max_tokens: 500,
      messages: [{ role: 'user', content: prompt }],
    });

    const narrative = response.content
      .filter(c => c.type === 'text')
      .map(c => (c as { type: 'text'; text: string }).text)
      .join('');

    await db.query(
      `UPDATE selector_scores
       SET coaching_narrative = $1, narrative_generated_at = NOW()
       WHERE team_member_id = $2 AND week_ending = $3`,
      [narrative, memberId, weekEnding],
    );
  } catch (err) {
    console.error(`[The Selector] Narrative generation failed for ${memberId}:`, err);
  }
}

async function updateLeaguePositions(weekEnding: string): Promise<void> {
  const venues = await db.query<{ id: string; total_score: string }>(
    `SELECT id, total_score FROM venue_scores WHERE week_ending = $1 ORDER BY total_score DESC`,
    [weekEnding],
  );

  for (let i = 0; i < venues.rows.length; i++) {
    await db.query(
      `UPDATE venue_scores SET league_position = $1 WHERE id = $2`,
      [i + 1, venues.rows[i]!.id],
    );
  }
}

function getMostRecentSunday(): string {
  const today = new Date();
  const day = today.getDay();
  const diff = day === 0 ? 0 : 7 - day;
  const sunday = new Date(today);
  sunday.setDate(today.getDate() - (day === 0 ? 0 : day));
  return sunday.toISOString().split('T')[0]!;
}

function round2(n: number): number {
  return Math.round(n * 100) / 100;
}
