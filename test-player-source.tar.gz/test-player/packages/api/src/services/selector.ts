// ================================================================
// THE SELECTOR — Scoring Engine
// Pure functions. No database. No side effects.
// 40% manager assessment + 40% EPOS signals + 20% operational
// ================================================================

export interface AssessmentInput {
  productConfidence:  number; // 1-5
  guestWarmth:        number; // 1-5
  tableReading:       number; // 1-5
  valuesAlignment:    number; // 1-5
  coachingTier:       'could-say' | 'should-say' | 'have-to';
}

export interface EposInput {
  foodAttachmentRate?:    number | null; // 0.0-1.0
  dessertConversionRate?: number | null; // 0.0-1.0
  coffeeConversionRate?:  number | null; // 0.0-1.0
  wineAttachmentRate?:    number | null; // 0.0-1.0
  coverValueIndex?:       number | null; // 1.0 = average
}

export interface OperationalInput {
  rotaAdherencePct?: number | null; // 0-100
  trailScore?:       number | null; // 0-100
}

export interface SelectorResult {
  totalScore:        number; // 0-100
  assessmentScore:   number; // 0-100 (40% weight)
  eposScore:         number; // 0-100 (40% weight)
  operationalScore:  number; // 0-100 (20% weight)
  tier:              'could-say' | 'should-say' | 'have-to' | 'review';
  programmeStatus:   'on-programme' | 'under-review' | 'not-yet';
  breakdown:         Record<string, number>;
  dataCompleteness:  number; // 0.0-1.0 — how much data was available
}

// ----------------------------------------------------------------
// COMPONENT SCORES
// ----------------------------------------------------------------

/**
 * Score the manager assessment component (0-100).
 * Four dimensions averaged, then multiplied by tier bonus.
 * Low values alignment can block the Could Say tier.
 */
export function scoreAssessment(input: AssessmentInput): number {
  const avg = (
    input.productConfidence +
    input.guestWarmth +
    input.tableReading +
    input.valuesAlignment
  ) / 4;

  // Convert 1-5 to 0-100
  const base = ((avg - 1) / 4) * 100;

  // Tier modifier — manager's direct classification carries weight
  const tierBonus = {
    'could-say':  10,
    'should-say':  0,
    'have-to':   -10,
  }[input.coachingTier];

  return clamp(round2(base + tierBonus), 0, 100);
}

/**
 * Score the EPOS signals component (0-100).
 * Attachment and conversion rates, weighted by importance.
 * Missing data gracefully handled — only score what we have.
 */
export function scoreEpos(input: EposInput): { score: number; completeness: number } {
  const metrics: Array<{ value: number | null | undefined; weight: number; max: number }> = [
    { value: input.foodAttachmentRate,    weight: 0.30, max: 1.0 },
    { value: input.dessertConversionRate, weight: 0.25, max: 1.0 },
    { value: input.coffeeConversionRate,  weight: 0.15, max: 1.0 },
    { value: input.wineAttachmentRate,    weight: 0.20, max: 1.0 },
    { value: input.coverValueIndex != null
        ? Math.min(input.coverValueIndex, 1.5) / 1.5  // normalise to 0-1, cap at 150%
        : null,
      weight: 0.10, max: 1.0 },
  ];

  let weightedSum = 0;
  let totalWeight = 0;

  for (const m of metrics) {
    if (m.value == null) continue;
    const normalised = clamp(m.value / m.max, 0, 1);
    weightedSum += normalised * m.weight;
    totalWeight += m.weight;
  }

  if (totalWeight === 0) return { score: 0, completeness: 0 };

  const score = round2((weightedSum / totalWeight) * 100);
  const completeness = round2(totalWeight); // how much of the full 1.0 weight was covered

  return { score, completeness };
}

/**
 * Score the operational component (0-100).
 * Rota adherence and Trail compliance, equal weight.
 */
export function scoreOperational(input: OperationalInput): { score: number; completeness: number } {
  const parts: number[] = [];

  if (input.rotaAdherencePct != null) parts.push(clamp(input.rotaAdherencePct, 0, 100));
  if (input.trailScore != null)       parts.push(clamp(input.trailScore, 0, 100));

  if (parts.length === 0) return { score: 0, completeness: 0 };

  const score = round2(parts.reduce((a, b) => a + b, 0) / parts.length);
  const completeness = parts.length / 2;

  return { score, completeness };
}

// ----------------------------------------------------------------
// THE SELECTOR — COMPOSITE SCORE
// ----------------------------------------------------------------

/**
 * Run The Selector on one team member for one week.
 * Returns the composite score, tier and programme status.
 */
export function runSelector(params: {
  assessment:   AssessmentInput | null;
  epos:         EposInput | null;
  operational:  OperationalInput | null;
}): SelectorResult {
  const { assessment, epos, operational } = params;

  // --- Component scores ---
  const assessmentScore = assessment ? scoreAssessment(assessment) : null;
  const eposResult      = epos       ? scoreEpos(epos)             : null;
  const opsResult       = operational? scoreOperational(operational): null;

  // Weights: 40 / 40 / 20
  // If a component is missing, redistribute weight proportionally
  const weights = {
    assessment:  assessment  ? 0.40 : 0,
    epos:        epos        ? 0.40 : 0,
    operational: operational ? 0.20 : 0,
  };

  const totalWeight = weights.assessment + weights.epos + weights.operational;

  let totalScore = 0;
  const breakdown: Record<string, number> = {};

  if (assessmentScore != null && totalWeight > 0) {
    const contribution = (assessmentScore * weights.assessment) / totalWeight;
    totalScore += contribution;
    breakdown['assessment'] = round2(assessmentScore);
    breakdown['assessment_contribution'] = round2(contribution);
  }

  if (eposResult != null && totalWeight > 0) {
    const contribution = (eposResult.score * weights.epos) / totalWeight;
    totalScore += contribution;
    breakdown['epos'] = round2(eposResult.score);
    breakdown['epos_completeness'] = round2(eposResult.completeness);
    breakdown['epos_contribution'] = round2(contribution);
  }

  if (opsResult != null && totalWeight > 0) {
    const contribution = (opsResult.score * weights.operational) / totalWeight;
    totalScore += contribution;
    breakdown['operational'] = round2(opsResult.score);
    breakdown['operational_completeness'] = round2(opsResult.completeness);
    breakdown['operational_contribution'] = round2(contribution);
  }

  totalScore = round2(clamp(totalScore, 0, 100));

  // Data completeness — how much of the full picture do we have
  const dataCompleteness = round2(totalWeight);

  // --- Tier assignment ---
  // Manager's coaching tier classification has veto power.
  // Low values alignment (<3) blocks Could Say regardless of score.
  const managerTier = assessment?.coachingTier ?? null;
  const valuesOk    = assessment == null || assessment.valuesAlignment >= 3;

  let tier: SelectorResult['tier'];

  if (!valuesOk) {
    // Values alignment failure — cannot be on programme
    tier = 'review';
  } else if (managerTier === 'could-say' && totalScore >= 85) {
    tier = 'could-say';
  } else if (totalScore >= 70 && (managerTier === 'could-say' || managerTier === 'should-say')) {
    tier = 'should-say';
  } else if (totalScore >= 50) {
    tier = 'have-to';
  } else {
    tier = 'review';
  }

  // --- Programme status ---
  let programmeStatus: SelectorResult['programmeStatus'];
  if (tier === 'could-say' || tier === 'should-say') {
    programmeStatus = 'on-programme';
  } else if (tier === 'review') {
    programmeStatus = 'under-review';
  } else {
    programmeStatus = 'not-yet';
  }

  return {
    totalScore,
    assessmentScore: assessmentScore ?? 0,
    eposScore:       eposResult?.score ?? 0,
    operationalScore: opsResult?.score ?? 0,
    tier,
    programmeStatus,
    breakdown,
    dataCompleteness,
  };
}

/**
 * Rank an array of scored team members within a venue.
 * Returns the same array with rankInVenue added (1 = highest score).
 */
export function rankMembers<T extends { memberId: string; totalScore: number }>(
  members: T[],
): Array<T & { rankInVenue: number }> {
  const sorted = [...members].sort((a, b) => b.totalScore - a.totalScore);
  return sorted.map((m, i) => ({ ...m, rankInVenue: i + 1 }));
}

/**
 * Calculate a venue's aggregate score from its members.
 */
export function venueAggregateScore(memberScores: number[]): number {
  if (memberScores.length === 0) return 0;
  return round2(memberScores.reduce((a, b) => a + b, 0) / memberScores.length);
}

// ----------------------------------------------------------------
// HELPERS
// ----------------------------------------------------------------
function clamp(n: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, n));
}

function round2(n: number): number {
  return Math.round(n * 100) / 100;
}
