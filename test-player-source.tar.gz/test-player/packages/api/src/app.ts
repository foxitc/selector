// app.ts
import express from 'express';
import helmet from 'helmet';
import cors from 'cors';
import morgan from 'morgan';
import rateLimit from 'express-rate-limit';
import { env } from './config/env.js';
import routes from './v1/routes.js';

export function createApp() {
  const app = express();

  app.use(helmet({ contentSecurityPolicy: false }));
  app.set('trust proxy', 1);

  const origins = env.ALLOWED_ORIGINS.split(',').map(o => o.trim());
  app.use(cors({
    origin: (origin, cb) => (!origin || origins.includes(origin) ? cb(null, true) : cb(new Error('CORS'))),
    credentials: true,
  }));

  app.use(rateLimit({ windowMs: 60_000, max: 300, standardHeaders: true, legacyHeaders: false }));
  app.use(express.json({ limit: '2mb' }));
  app.use(morgan(env.NODE_ENV === 'production' ? 'combined' : 'dev'));

  app.get('/health', (_, res) => res.json({
    status: 'ok',
    service: 'Test Player API',
    timestamp: new Date().toISOString(),
  }));

  app.use('/api/v1', routes);

  app.use((err: Error, _req: express.Request, res: express.Response, _next: express.NextFunction) => {
    if (err.name === 'ZodError') {
      return res.status(400).json({ data: null, error: { message: 'Validation error', details: err.message } });
    }
    console.error('[Error]', err);
    res.status(500).json({ data: null, error: { message: env.NODE_ENV === 'production' ? 'Internal error' : err.message } });
  });

  return app;
}
