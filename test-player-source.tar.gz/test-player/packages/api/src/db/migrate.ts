import fs from 'fs';
import path from 'path';
import { Pool } from 'pg';
import dotenv from 'dotenv';
dotenv.config();

const pool = new Pool({
  host: process.env['DB_HOST'], port: Number(process.env['DB_PORT'] ?? 5432),
  database: process.env['DB_NAME'], user: process.env['DB_USER'], password: process.env['DB_PASSWORD'],
});

async function migrate() {
  const client = await pool.connect();
  try {
    await client.query(`CREATE TABLE IF NOT EXISTS _migrations (id SERIAL PRIMARY KEY, filename VARCHAR(255) UNIQUE, applied_at TIMESTAMPTZ DEFAULT NOW())`);
    const { rows } = await client.query<{ filename: string }>('SELECT filename FROM _migrations');
    const applied = new Set(rows.map(r => r.filename));
    if (!applied.has('schema.sql')) {
      const schemaPath = path.join(__dirname, 'schema.sql');
      console.log(`  [apply] schema.sql`);
      const sql = fs.readFileSync(schemaPath, 'utf8');
      await client.query('BEGIN');
      await client.query(sql);
      await client.query(`INSERT INTO _migrations (filename) VALUES ('schema.sql')`);
      await client.query('COMMIT');
      console.log('  Schema applied');
    } else {
      console.log('  Schema already applied');
    }
  } catch (err) {
    console.error('Migration failed:', err);
    await client.query('ROLLBACK').catch(() => {});
    throw err;
  } finally { client.release(); await pool.end(); }
}
migrate().catch(() => process.exit(1));
