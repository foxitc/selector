import { Pool } from 'pg';
import bcrypt from 'bcryptjs';
import { randomUUID } from 'crypto';
import dotenv from 'dotenv';
dotenv.config();

const pool = new Pool({
  host: process.env['DB_HOST'], port: Number(process.env['DB_PORT'] ?? 5432),
  database: process.env['DB_NAME'], user: process.env['DB_USER'], password: process.env['DB_PASSWORD'],
});

type Row = Record<string, unknown>;

async function q(sql: string, params: unknown[] = []): Promise<Row[]> {
  return (await pool.query<Row>(sql, params)).rows;
}

async function seed() {
  console.log('\n[Seed] Cat & Wickets — Test Player\n');

  // Venues
  const venues = [
    { name: 'The Griffin Inn', short: 'GRI', slug: 'griffin-inn' },
    { name: 'Long Hop',        short: 'LHP', slug: 'long-hop' },
    { name: 'Tap & Run',       short: 'TAP', slug: 'tap-and-run' },
  ];

  const venueIds: Record<string, string> = {};
  for (const v of venues) {
    const [row] = await q(
      `INSERT INTO venues (id, name, short_name, slug) VALUES ($1,$2,$3,$4)
       ON CONFLICT (slug) DO UPDATE SET name = EXCLUDED.name RETURNING id`,
      [randomUUID(), v.name, v.short, v.slug],
    );
    venueIds[v.slug] = row!['id'] as string;
    console.log(`  venue  ${v.name}`);
  }

  // Team members
  const squad: Array<{ venue: string; first: string; last: string; role: string; dept: string; color: string }> = [
    { venue:'griffin-inn', first:'Marcus', last:'Bennett',  role:'Head Chef',        dept:'Kitchen', color:'#fd6f53' },
    { venue:'griffin-inn', first:'Amy',    last:'Chen',     role:'Sous Chef',        dept:'Kitchen', color:'#9db3c1' },
    { venue:'griffin-inn', first:'Darren', last:'Walsh',    role:'Chef de Partie',   dept:'Kitchen', color:'#b38b6d' },
    { venue:'griffin-inn', first:'Sarah',  last:'Thompson', role:'Bar Manager',      dept:'Bar',     color:'#6e9277' },
    { venue:'griffin-inn', first:'James',  last:'Kirk',     role:'Senior Server',    dept:'FOH',     color:'#a8a28a' },
    { venue:'long-hop',    first:'Sophie', last:'Patel',    role:'Head Chef',        dept:'Kitchen', color:'#fd6f53' },
    { venue:'long-hop',    first:'Tom',    last:'Hughes',   role:'Sous Chef',        dept:'Kitchen', color:'#9db3c1' },
    { venue:'long-hop',    first:'Emma',   last:'Lewis',    role:'General Manager',  dept:'Management', color:'#6e9277' },
    { venue:'long-hop',    first:'Jake',   last:'Morrison', role:'Senior Server',    dept:'FOH',     color:'#a8a28a' },
    { venue:'tap-and-run', first:'Priya',  last:'Sharma',   role:'Head Chef',        dept:'Kitchen', color:'#fd6f53' },
    { venue:'tap-and-run', first:'Dan',    last:'Fox',      role:'Sous Chef',        dept:'Kitchen', color:'#9db3c1' },
    { venue:'tap-and-run', first:'Chloe',  last:'Adams',    role:'Bar Manager',      dept:'Bar',     color:'#b38b6d' },
    { venue:'tap-and-run', first:'Rob',    last:'Clarke',   role:'Senior Server',    dept:'FOH',     color:'#a8a28a' },
  ];

  for (const m of squad) {
    await q(
      `INSERT INTO team_members (id, venue_id, first_name, last_name, display_name, role, department, avatar_initials, avatar_color)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)
       ON CONFLICT DO NOTHING`,
      [randomUUID(), venueIds[m.venue]!, m.first, m.last, `${m.first} ${m.last}`, m.role, m.dept,
       (m.first[0]! + m.last[0]!).toUpperCase(), m.color],
    );
    console.log(`  member ${m.first} ${m.last} — ${m.venue}`);
  }

  // Admin user
  const adminEmail    = process.env['ADMIN_EMAIL']    ?? 'admin@catandwickets.com';
  const adminPassword = process.env['ADMIN_PASSWORD'] ?? 'changeme123!';
  const hash = await bcrypt.hash(adminPassword, 12);
  await q(
    `INSERT INTO platform_users (id, email, password_hash, first_name, last_name, role)
     VALUES ($1,$2,$3,'Admin','User','admin')
     ON CONFLICT (email) DO UPDATE SET password_hash = EXCLUDED.password_hash`,
    [randomUUID(), adminEmail, hash],
  );
  console.log(`\n  admin  ${adminEmail}`);

  // Coach users (one per venue)
  const coaches = [
    { email:'coach.griffin@catandwickets.com', first:'James', last:'Hartley', venue:'griffin-inn' },
    { email:'coach.longhop@catandwickets.com', first:'Sarah', last:'Booth',   venue:'long-hop' },
    { email:'coach.taprun@catandwickets.com',  first:'Mike',  last:'Davies',  venue:'tap-and-run' },
  ];
  for (const c of coaches) {
    const coachHash = await bcrypt.hash('coach123!', 12);
    await q(
      `INSERT INTO platform_users (id, email, password_hash, first_name, last_name, role, venue_id)
       VALUES ($1,$2,$3,$4,$5,'coach',$6)
       ON CONFLICT (email) DO NOTHING`,
      [randomUUID(), c.email, coachHash, c.first, c.last, venueIds[c.venue]!],
    );
    console.log(`  coach  ${c.email}`);
  }

  console.log('\n[Seed] Complete.\n');
  console.log('Default passwords:');
  console.log('  Admin:  changeme123!');
  console.log('  Coaches: coach123!');
  console.log('\nChange these immediately after first login.\n');

  await pool.end();
}

seed().catch(err => { console.error(err); process.exit(1); });
