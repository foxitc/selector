// ================================================================
// THE CLUB — Connector Framework
// Each provider implements ConnectorAdapter.
// Add a new provider: create one file, register it.
// ================================================================

import axios, { type AxiosInstance, type AxiosError } from 'axios';
import { createCipheriv, createDecipheriv, randomBytes } from 'crypto';
import { env } from '../config/env.js';

// ----------------------------------------------------------------
// ENCRYPTION (AES-256-GCM)
// ----------------------------------------------------------------
export function encryptCredentials(creds: Record<string, string>): string {
  const key = Buffer.from(env.ENCRYPTION_KEY, 'hex');
  const iv = randomBytes(12);
  const cipher = createCipheriv('aes-256-gcm', key, iv);
  const encrypted = Buffer.concat([cipher.update(JSON.stringify(creds), 'utf8'), cipher.final()]);
  const tag = cipher.getAuthTag();
  return [iv.toString('hex'), tag.toString('hex'), encrypted.toString('hex')].join(':');
}

export function decryptCredentials(ciphertext: string): Record<string, string> {
  const [ivHex, tagHex, encHex] = ciphertext.split(':') as [string, string, string];
  const key = Buffer.from(env.ENCRYPTION_KEY, 'hex');
  const decipher = createDecipheriv('aes-256-gcm', key, Buffer.from(ivHex, 'hex'));
  decipher.setAuthTag(Buffer.from(tagHex, 'hex'));
  return JSON.parse(
    Buffer.concat([decipher.update(Buffer.from(encHex, 'hex')), decipher.final()]).toString('utf8')
  );
}

// ----------------------------------------------------------------
// CONNECTOR ADAPTER INTERFACE
// ----------------------------------------------------------------
export interface TestResult {
  success: boolean;
  message: string;
  durationMs: number;
  sampleFields?: string[];
}

export interface SyncResult {
  recordsFetched: number;
  recordsStored: number;
  errors: string[];
}

export interface ConnectorConfig {
  id: string;
  provider: string;
  baseUrl: string;
  authType: 'api_key' | 'bearer' | 'basic';
  authConfig: Record<string, unknown>;
  credentials: Record<string, string>;
  timeoutMs?: number;
}

export abstract class BaseConnector {
  protected client: AxiosInstance;

  constructor(protected config: ConnectorConfig) {
    this.client = axios.create({
      baseURL: config.baseUrl,
      timeout: config.timeoutMs ?? 15000,
      headers: this.buildAuthHeaders(),
    });
  }

  abstract get provider(): string;
  abstract testConnection(): Promise<TestResult>;

  /**
   * Sync data for a specific venue and week.
   * Returns counts of records fetched and stored.
   */
  abstract syncVenue(venueId: string, weekEnding: string): Promise<SyncResult>;

  protected buildAuthHeaders(): Record<string, string> {
    const { authType, authConfig, credentials } = this.config;
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
      'Accept':       'application/json',
      'User-Agent':   'TestPlayer/1.0 (Cat & Wickets)',
    };

    switch (authType) {
      case 'api_key': {
        const headerName = (authConfig['headerName'] as string | undefined) ?? 'X-API-Key';
        if (credentials['apiKey']) headers[headerName] = credentials['apiKey'];
        break;
      }
      case 'bearer': {
        if (credentials['token']) headers['Authorization'] = `Bearer ${credentials['token']}`;
        break;
      }
      case 'basic': {
        if (credentials['username'] && credentials['password']) {
          headers['Authorization'] = `Basic ${Buffer.from(
            `${credentials['username']}:${credentials['password']}`
          ).toString('base64')}`;
        }
        break;
      }
    }
    return headers;
  }

  protected async get<T = unknown>(path: string, params?: Record<string, string>): Promise<T> {
    const response = await this.client.get<T>(path, { params });
    return response.data;
  }

  protected async post<T = unknown>(path: string, body: unknown): Promise<T> {
    const response = await this.client.post<T>(path, body);
    return response.data;
  }

  protected axiosError(err: unknown): string {
    const e = err as AxiosError;
    if (e.response) return `HTTP ${e.response.status}: ${e.response.statusText}`;
    return (e as Error).message;
  }
}
