import { type BaseConnector, type ConnectorConfig } from './base.js';

const REGISTRY = new Map<string, new (config: ConnectorConfig) => BaseConnector>();

export function getConnector(config: ConnectorConfig): BaseConnector {
  const Cls = REGISTRY.get(config.provider);
  if (!Cls) {
    throw new Error(`No connector adapter for: ${config.provider}. Register it with registerConnector().`);
  }
  return new Cls(config);
}

export function registerConnector(provider: string, cls: new (config: ConnectorConfig) => BaseConnector): void {
  REGISTRY.set(provider, cls);
  console.log(`[Connectors] Registered: ${provider}`);
}

export const supportedProviders = (): string[] => Array.from(REGISTRY.keys());
