import { createApp } from './app.js';
import { env } from './config/env.js';
import { db } from './config/database.js';
import { runSelectorForWeek } from './services/selectorRunner.js';
import cron from 'node-cron';

const app = createApp();

const server = app.listen(env.PORT, () => {
  console.log(`
  ╔══════════════════════════════════════════╗
  ║        Test Player API — The Club        ║
  ╠══════════════════════════════════════════╣
  ║  Port : ${String(env.PORT).padEnd(33)}║
  ║  Env  : ${env.NODE_ENV.padEnd(33)}║
  ╚══════════════════════════════════════════╝
  `);
});

// The Selector runs every Sunday night at 23:00
// to score the completed week before Monday morning
cron.schedule('0 23 * * 0', async () => {
  console.log('[The Selector] Weekly run starting...');
  try {
    const result = await runSelectorForWeek();
    console.log(`[The Selector] Complete:`, result);
  } catch (err) {
    console.error('[The Selector] Weekly run failed:', err);
  }
});

async function shutdown(signal: string) {
  console.log(`\n[Server] ${signal} — shutting down`);
  server.close(async () => {
    await db.pool.end();
    process.exit(0);
  });
  setTimeout(() => process.exit(1), 10_000);
}

process.on('SIGTERM', () => void shutdown('SIGTERM'));
process.on('SIGINT',  () => void shutdown('SIGINT'));
process.on('unhandledRejection', (r) => console.error('[Server] Unhandled rejection:', r));
