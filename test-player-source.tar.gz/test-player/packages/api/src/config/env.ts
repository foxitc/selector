import { z } from 'zod';
import dotenv from 'dotenv';
dotenv.config();

const schema = z.object({
  NODE_ENV:              z.enum(['development', 'staging', 'production']).default('development'),
  PORT:                  z.string().default('3100').transform(Number),
  DB_HOST:               z.string().min(1),
  DB_PORT:               z.string().default('5432').transform(Number),
  DB_NAME:               z.string().min(1),
  DB_USER:               z.string().min(1),
  DB_PASSWORD:           z.string().min(1),
  DB_SSL:                z.string().default('false').transform(v => v === 'true'),
  JWT_SECRET:            z.string().min(32),
  ENCRYPTION_KEY:        z.string().length(64),
  ALLOWED_ORIGINS:       z.string().default('http://localhost:3101'),
  ANTHROPIC_API_KEY:     z.string().startsWith('sk-ant-').optional(),
  ADMIN_EMAIL:           z.string().email().optional(),
  ADMIN_PASSWORD:        z.string().min(8).optional(),
});

const result = schema.safeParse(process.env);
if (!result.success) {
  console.error('\n[Test Player] Invalid environment:\n');
  result.error.issues.forEach(i => console.error(`  ${i.path.join('.')}: ${i.message}`));
  process.exit(1);
}

export const env = result.data;
