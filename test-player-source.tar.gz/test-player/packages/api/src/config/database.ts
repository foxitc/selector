import { Pool, type QueryResult } from 'pg';
import { env } from './env.js';

const pool = new Pool({
  host:     env.DB_HOST,
  port:     env.DB_PORT,
  database: env.DB_NAME,
  user:     env.DB_USER,
  password: env.DB_PASSWORD,
  max:      20,
  ssl:      env.DB_SSL ? { rejectUnauthorized: false } : undefined,
});

pool.on('error', (err: Error) => console.error('[DB] Pool error:', err.message));

type Row = Record<string, unknown>;

async function query<T extends Row = Row>(text: string, params?: unknown[]): Promise<QueryResult<T>> {
  return pool.query<T>(text, params);
}

async function transaction<T>(fn: (client: import('pg').PoolClient) => Promise<T>): Promise<T> {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const result = await fn(client);
    await client.query('COMMIT');
    return result;
  } catch (err) {
    await client.query('ROLLBACK');
    throw err;
  } finally {
    client.release();
  }
}

export const db = { query, transaction, pool };
