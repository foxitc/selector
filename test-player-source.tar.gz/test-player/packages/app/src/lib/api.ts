// ================================================================
// TEST PLAYER — API Client
// ================================================================

const BASE = '/api/v1';

const getToken = () => sessionStorage.getItem('tp_token');
export const setToken = (t: string) => sessionStorage.setItem('tp_token', t);
export const clearToken = () => sessionStorage.removeItem('tp_token');

export class ApiError extends Error {
  constructor(public status: number, message: string) {
    super(message);
    this.name = 'ApiError';
  }
}

async function request<T>(path: string, init: RequestInit = {}): Promise<T> {
  const token = getToken();
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    ...(token ? { Authorization: `Bearer ${token}` } : {}),
    ...(init.headers as Record<string, string> ?? {}),
  };

  const res = await fetch(`${BASE}${path}`, { ...init, headers });
  const json = await res.json() as { data: T; error: { message: string } | null };

  if (!res.ok || json.error) {
    if (res.status === 401) { clearToken(); window.location.href = '/login'; }
    throw new ApiError(res.status, json.error?.message ?? 'Request failed');
  }
  return json.data;
}

export const api = {
  get:    <T>(path: string) => request<T>(path),
  post:   <T>(path: string, body: unknown) => request<T>(path, { method: 'POST', body: JSON.stringify(body) }),
  put:    <T>(path: string, body: unknown) => request<T>(path, { method: 'PUT',  body: JSON.stringify(body) }),
  delete: <T>(path: string) => request<T>(path, { method: 'DELETE' }),
};
