import React from 'react';
import ReactDOM from 'react-dom/client';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import './index.css';

import { AppShell } from './components/layout/AppShell';
import { LoginPage } from './pages/LoginPage';
import { SquadPage } from './pages/SquadPage';
import { ScoresPage } from './pages/ScoresPage';
import { AssessmentPage } from './pages/AssessmentPage';
import { ConnectorsPage } from './pages/ConnectorsPage';
import { DisplaysPage } from './pages/DisplaysPage';
import { TVDisplay } from './pages/TVDisplay';
import { useAuth } from './hooks/useAuth';

const qc = new QueryClient({
  defaultOptions: {
    queries: { staleTime: 30_000, retry: 1, refetchOnWindowFocus: false },
  },
});

function RequireAuth({ children }: { children: React.ReactNode }) {
  const { isAuthenticated } = useAuth();
  return isAuthenticated ? <>{children}</> : <Navigate to="/login" replace />;
}

function ReportsPage() {
  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="font-heading font-bold text-2xl tracking-wide uppercase text-cw-black">Reports</h1>
          <p className="font-serif italic text-cw-stone text-sm mt-0.5">AI coaching output from The Selector</p>
        </div>
      </div>
      <div className="cw-card p-8 text-center">
        <p className="font-serif italic text-cw-stone">Reports coming soon — complete manager assessments and run The Selector to generate AI coaching narratives.</p>
      </div>
    </div>
  );
}

function SettingsPage() {
  return (
    <div>
      <h1 className="font-heading font-bold text-2xl tracking-wide uppercase text-cw-black mb-6">Settings</h1>
      <div className="cw-card p-8 text-center">
        <p className="font-serif italic text-cw-stone">Settings coming soon.</p>
      </div>
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={qc}>
      <BrowserRouter>
        <Routes>
          {/* TV display — public, no auth */}
          <Route path="/display/:token" element={<TVDisplay />} />
          <Route path="/login" element={<LoginPage />} />

          {/* Protected admin */}
          <Route element={<RequireAuth><AppShell /></RequireAuth>}>
            <Route index element={<Navigate to="/squad" replace />} />
            <Route path="/squad"      element={<SquadPage />} />
            <Route path="/scores"     element={<ScoresPage />} />
            <Route path="/assessment" element={<AssessmentPage />} />
            <Route path="/reports"    element={<ReportsPage />} />
            <Route path="/displays"   element={<DisplaysPage />} />
            <Route path="/connectors" element={<ConnectorsPage />} />
            <Route path="/settings"   element={<SettingsPage />} />
          </Route>
        </Routes>
      </BrowserRouter>
    </QueryClientProvider>
  );
}

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode><App /></React.StrictMode>,
);
