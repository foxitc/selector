import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Plug, CheckCircle2, XCircle, AlertCircle, Plus, Key, TestTube2 } from 'lucide-react';
import {
  PageHeader, Card, Button, Input, Spinner, EmptyState, Modal,
} from '../components/ui';
import { api } from '../lib/api';

interface Connector {
  id: string;
  name: string;
  provider: string;
  base_url: string;
  auth_type: 'api_key' | 'bearer' | 'basic';
  is_active: boolean;
  has_credentials: boolean;
  last_sync_at: string | null;
  last_sync_status: 'success' | 'failed' | 'running' | null;
  last_sync_message: string | null;
}

interface TestResult {
  success: boolean;
  message: string;
  durationMs: number;
  sampleFields?: string[];
}

export function ConnectorsPage() {
  const qc = useQueryClient();
  const [showAdd, setShowAdd] = useState(false);
  const [credModal, setCredModal] = useState<Connector | null>(null);
  const [testResult, setTestResult] = useState<{ connector: Connector; result: TestResult } | null>(null);

  const { data: connectors, isLoading } = useQuery({
    queryKey: ['connectors'],
    queryFn: () => api.get<Connector[]>('/connectors'),
  });

  const testMutation = useMutation({
    mutationFn: (id: string) => api.post<TestResult>(`/connectors/${id}/test`, {}),
    onSuccess: (result, id) => {
      const connector = connectors?.find(c => c.id === id);
      if (connector) setTestResult({ connector, result });
      void qc.invalidateQueries({ queryKey: ['connectors'] });
    },
  });

  return (
    <div>
      <PageHeader
        title="Connectors"
        subtitle="API integrations feeding data into The Selector"
        action={
          <Button variant="primary" size="sm" icon={<Plus className="w-3.5 h-3.5" />} onClick={() => setShowAdd(true)}>
            Add connector
          </Button>
        }
      />

      {isLoading ? (
        <div className="flex justify-center py-16"><Spinner className="w-6 h-6" /></div>
      ) : !connectors?.length ? (
        <Card>
          <EmptyState
            icon={<Plug className="w-8 h-8" />}
            title="No connectors configured"
            description="Add your API integrations to start feeding data into The Selector"
            action={<Button variant="primary" size="sm" onClick={() => setShowAdd(true)} icon={<Plus className="w-3.5 h-3.5" />}>Add connector</Button>}
          />
        </Card>
      ) : (
        <div className="space-y-3">
          {connectors.map(c => (
            <ConnectorRow
              key={c.id}
              connector={c}
              onAddCreds={() => setCredModal(c)}
              onTest={() => testMutation.mutate(c.id)}
              testing={testMutation.isPending && testMutation.variables === c.id}
            />
          ))}
        </div>
      )}

      {/* Add connector modal */}
      <AddConnectorModal
        open={showAdd}
        onClose={() => setShowAdd(false)}
        onSaved={() => { setShowAdd(false); void qc.invalidateQueries({ queryKey: ['connectors'] }); }}
      />

      {/* Credentials modal */}
      {credModal && (
        <CredentialsModal
          connector={credModal}
          onClose={() => setCredModal(null)}
          onSaved={() => { setCredModal(null); void qc.invalidateQueries({ queryKey: ['connectors'] }); }}
        />
      )}

      {/* Test result modal */}
      {testResult && (
        <Modal
          open
          onClose={() => setTestResult(null)}
          title={`Connection test — ${testResult.connector.name}`}
          subtitle={testResult.result.success ? 'Connected successfully' : 'Connection failed'}
        >
          <div className="space-y-4">
            <div className={`flex items-start gap-3 p-4 rounded border ${testResult.result.success ? 'bg-green-50 border-green-200' : 'bg-red-50 border-red-200'}`}>
              {testResult.result.success
                ? <CheckCircle2 className="w-5 h-5 text-cw-sage flex-shrink-0 mt-0.5" />
                : <XCircle className="w-5 h-5 text-cw-coral flex-shrink-0 mt-0.5" />}
              <div>
                <p className="font-heading font-semibold text-sm text-cw-black">{testResult.result.message}</p>
                <p className="font-body text-xs text-cw-stone mt-1">{testResult.result.durationMs}ms response time</p>
              </div>
            </div>
            {testResult.result.sampleFields && (
              <div>
                <div className="cw-label mb-2">Fields available</div>
                <div className="flex flex-wrap gap-1.5">
                  {testResult.result.sampleFields.map(f => (
                    <span key={f} className="px-2 py-1 bg-cw-linen text-cw-stone font-body text-xs rounded">{f}</span>
                  ))}
                </div>
              </div>
            )}
            <Button variant="secondary" className="w-full" onClick={() => setTestResult(null)}>Close</Button>
          </div>
        </Modal>
      )}
    </div>
  );
}

function ConnectorRow({ connector: c, onAddCreds, onTest, testing }: {
  connector: Connector;
  onAddCreds: () => void;
  onTest: () => void;
  testing: boolean;
}) {
  const statusMap: Record<string, string> = { success: 'bg-cw-sage', failed: 'bg-cw-coral', running: 'bg-cw-sand animate-pulse' };
  const statusColor = (c.last_sync_status ? statusMap[c.last_sync_status] : undefined) ?? 'bg-cw-stone';

  return (
    <Card padding="none">
      <div className="flex items-center gap-4 px-5 py-4">
        {/* Status dot */}
        <div className={`w-2.5 h-2.5 rounded-full flex-shrink-0 ${statusColor}`} />

        {/* Info */}
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="font-heading font-bold text-sm text-cw-black">{c.name}</span>
            <span className="font-heading text-xs text-cw-stone uppercase tracking-wide px-2 py-0.5 bg-cw-linen rounded">
              {c.provider}
            </span>
            <span className="font-heading text-xs text-cw-stone uppercase tracking-wide px-2 py-0.5 bg-cw-linen rounded">
              {c.auth_type}
            </span>
          </div>
          <p className="font-body text-xs text-cw-stone mt-0.5 truncate">{c.base_url}</p>
          {c.last_sync_at && (
            <p className="font-body text-xs text-cw-stone/60 mt-0.5">
              Last sync: {new Date(c.last_sync_at).toLocaleString('en-GB', { dateStyle: 'short', timeStyle: 'short' })}
              {c.last_sync_message && ` · ${c.last_sync_message}`}
            </p>
          )}
        </div>

        {/* Actions */}
        <div className="flex items-center gap-2 flex-shrink-0">
          {!c.has_credentials && (
            <div className="flex items-center gap-1.5 text-cw-coral mr-2">
              <AlertCircle className="w-3.5 h-3.5" />
              <span className="font-heading text-xs uppercase tracking-wide">No credentials</span>
            </div>
          )}
          <Button variant="ghost" size="sm" icon={<Key className="w-3.5 h-3.5" />} onClick={onAddCreds}>
            Credentials
          </Button>
          <Button variant="secondary" size="sm" icon={<TestTube2 className="w-3.5 h-3.5" />} loading={testing} onClick={onTest}>
            Test
          </Button>
        </div>
      </div>
    </Card>
  );
}

function AddConnectorModal({ open, onClose, onSaved }: {
  open: boolean; onClose: () => void; onSaved: () => void;
}) {
  const [form, setForm] = useState({ name: '', provider: '', baseUrl: '', authType: 'api_key' as 'api_key' | 'bearer' | 'basic' });
  const [error, setError] = useState('');

  const mutation = useMutation({
    mutationFn: () => api.post('/connectors', {
      name: form.name, provider: form.provider.toLowerCase().replace(/\s+/g, '-'),
      baseUrl: form.baseUrl, authType: form.authType, authConfig: {},
    }),
    onSuccess: onSaved,
    onError: (e) => setError(e instanceof Error ? e.message : 'Failed'),
  });

  return (
    <Modal open={open} onClose={onClose} title="Add connector" subtitle="Connect a new API data source">
      <div className="space-y-4">
        <Input label="Display name" placeholder="e.g. RotaReady" value={form.name}
          onChange={e => setForm(f => ({ ...f, name: e.target.value }))} />
        <Input label="Provider slug" placeholder="e.g. rotaready" value={form.provider}
          onChange={e => setForm(f => ({ ...f, provider: e.target.value }))}
          hint="Lowercase, no spaces. Must match the connector adapter name." />
        <Input label="Base URL" placeholder="https://api.provider.com/v1" value={form.baseUrl}
          onChange={e => setForm(f => ({ ...f, baseUrl: e.target.value }))} />
        <div className="space-y-1">
          <label className="cw-label block">Auth type</label>
          <select
            value={form.authType}
            onChange={e => setForm(f => ({ ...f, authType: e.target.value as typeof form.authType }))}
            className="w-full h-9 px-3 text-sm border border-cw-mist rounded bg-white font-body focus:outline-none"
          >
            <option value="api_key">API Key (header)</option>
            <option value="bearer">Bearer token</option>
            <option value="basic">Basic auth (username + password)</option>
          </select>
        </div>
        {error && <p className="text-xs text-cw-coral font-body">{error}</p>}
        <div className="flex justify-end gap-2 pt-2 border-t border-cw-mist">
          <Button variant="ghost" onClick={onClose}>Cancel</Button>
          <Button variant="primary" loading={mutation.isPending}
            onClick={() => mutation.mutate()}
            disabled={!form.name || !form.provider || !form.baseUrl}
          >
            Save connector
          </Button>
        </div>
      </div>
    </Modal>
  );
}

function CredentialsModal({ connector, onClose, onSaved }: {
  connector: Connector; onClose: () => void; onSaved: () => void;
}) {
  const [creds, setCreds] = useState<Record<string, string>>({});
  const [saved, setSaved] = useState(false);

  const fieldMap: Record<string, string[]> = {
    api_key: ['apiKey'],
    bearer:  ['token'],
    basic:   ['username', 'password'],
  };
  const fields = fieldMap[connector.auth_type] ?? ['apiKey'];

  const mutation = useMutation({
    mutationFn: () => api.post(`/connectors/${connector.id}/credentials`, creds),
    onSuccess: () => { setSaved(true); setTimeout(onSaved, 1000); },
  });

  return (
    <Modal open onClose={onClose} title={`Credentials — ${connector.name}`}
      subtitle="Stored encrypted. Never logged or exposed.">
      <div className="space-y-4">
        <div className="p-3 bg-cw-linen rounded border border-cw-sand text-xs font-body text-cw-stone">
          Credentials are encrypted with AES-256-GCM before storage. The key never leaves the server.
        </div>
        {fields.map(field => (
          <Input
            key={field}
            label={field === 'apiKey' ? 'API Key' : field.charAt(0).toUpperCase() + field.slice(1)}
            type={field === 'password' || field === 'apiKey' || field === 'token' ? 'password' : 'text'}
            placeholder={`Enter ${field}`}
            value={creds[field] ?? ''}
            onChange={e => setCreds(c => ({ ...c, [field]: e.target.value }))}
          />
        ))}
        {saved && (
          <div className="flex items-center gap-2 text-cw-sage">
            <CheckCircle2 className="w-4 h-4" />
            <span className="font-heading font-semibold text-sm uppercase tracking-wide">Credentials saved securely</span>
          </div>
        )}
        <div className="flex justify-end gap-2 pt-2 border-t border-cw-mist">
          <Button variant="ghost" onClick={onClose}>Cancel</Button>
          <Button variant="primary" loading={mutation.isPending} icon={<Key className="w-3.5 h-3.5" />}
            onClick={() => mutation.mutate()}
            disabled={fields.some(f => !creds[f])}
          >
            Save credentials
          </Button>
        </div>
      </div>
    </Modal>
  );
}
