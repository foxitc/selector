import React, { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { CheckCircle2, AlertCircle, ChevronRight } from 'lucide-react';
import {
  PageHeader, Card, Avatar, TierBadge, Button, StarRating,
  Textarea, Spinner, EmptyState,
} from '../components/ui';
import { api } from '../lib/api';
import { useAuth, currentWeek, formatWeek } from '../hooks/useAuth';

interface Member {
  id: string;
  display_name: string;
  first_name: string;
  avatar_initials: string;
  avatar_color: string;
  role: string | null;
  venue_id: string;
  venue_name: string;
}

interface Assessment {
  product_confidence: number;
  guest_warmth: number;
  table_reading: number;
  values_alignment: number;
  coaching_tier: 'could-say' | 'should-say' | 'have-to';
  coaching_note: string;
  dont_say_flags: string[];
}

const defaultAssessment = (): Assessment => ({
  product_confidence: 3, guest_warmth: 3, table_reading: 3, values_alignment: 3,
  coaching_tier: 'should-say', coaching_note: '', dont_say_flags: [],
});

const DONT_SAY = ['Are you still working on that?','No problem','You guys','Not a problem at all','Basically','To be honest','Actually','Obviously'];

const TIERS: Array<{ value: Assessment['coaching_tier']; label: string; desc: string; color: string }> = [
  { value: 'could-say',  label: 'Could Say',  desc: 'Test Player standard — highest level of hospitality craft', color: 'border-cw-slate bg-cw-slate/5' },
  { value: 'should-say', label: 'Should Say', desc: 'Strong, knowledgeable Cat & Wickets server', color: 'border-cw-sage bg-cw-sage/5' },
  { value: 'have-to',    label: 'Have To',    desc: 'Meeting minimum standards — development focus needed', color: 'border-cw-sand bg-cw-sand/5' },
];

export function AssessmentPage() {
  const { user } = useAuth();
  const qc = useQueryClient();
  const week = currentWeek();
  const [selectedMember, setSelectedMember] = useState<Member | null>(null);
  const [form, setForm] = useState<Assessment>(defaultAssessment());
  const [saved, setSaved] = useState(false);

  const { data: squad, isLoading } = useQuery({
    queryKey: ['squad', user?.venueId, week],
    queryFn: () => api.get<Member[]>(`/squad${user?.venueId ? `?venueId=${user.venueId}` : ''}`),
  });

  const { data: existing } = useQuery({
    queryKey: ['assessment', selectedMember?.id, week],
    queryFn: () => api.get<Assessment | null>(`/assessments/${selectedMember!.id}?weekEnding=${week}`),
    enabled: !!selectedMember,
  });

  useEffect(() => {
    if (existing) {
      setForm({
        product_confidence: existing.product_confidence,
        guest_warmth:       existing.guest_warmth,
        table_reading:      existing.table_reading,
        values_alignment:   existing.values_alignment,
        coaching_tier:      existing.coaching_tier,
        coaching_note:      existing.coaching_note ?? '',
        dont_say_flags:     existing.dont_say_flags ?? [],
      });
    } else if (existing === null) {
      setForm(defaultAssessment());
    }
  }, [existing]);

  const saveMutation = useMutation({
    mutationFn: () => api.post('/assessments', {
      teamMemberId:      selectedMember!.id,
      venueId:           selectedMember!.venue_id,
      weekEnding:        week,
      productConfidence: form.product_confidence,
      guestWarmth:       form.guest_warmth,
      tableReading:      form.table_reading,
      valuesAlignment:   form.values_alignment,
      coachingTier:      form.coaching_tier,
      coachingNote:      form.coaching_note || undefined,
      dontSayFlags:      form.dont_say_flags.length > 0 ? form.dont_say_flags : undefined,
    }),
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: ['squad'] });
      setSaved(true);
      setTimeout(() => { setSaved(false); setSelectedMember(null); }, 1500);
    },
  });

  const toggleDontSay = (phrase: string) =>
    setForm(f => ({
      ...f,
      dont_say_flags: f.dont_say_flags.includes(phrase)
        ? f.dont_say_flags.filter(p => p !== phrase)
        : [...f.dont_say_flags, phrase],
    }));

  if (isLoading) return <div className="flex justify-center py-16"><Spinner className="w-6 h-6" /></div>;

  return (
    <div>
      <PageHeader title="Assessment" subtitle={`The Coach's weekly assessment · ${formatWeek(week)}`} />
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        {/* Member list */}
        <div className="lg:col-span-1">
          <div className="cw-label mb-3">Select team member</div>
          <div className="space-y-2">
            {(squad ?? []).map(m => (
              <button key={m.id} onClick={() => setSelectedMember(m)}
                className={`w-full flex items-center gap-3 p-3 rounded border text-left transition-all
                  ${selectedMember?.id === m.id ? 'border-cw-coral bg-cw-coral/5' : 'border-cw-mist bg-white hover:border-cw-sand'}`}>
                <Avatar initials={m.avatar_initials} color={m.avatar_color} size="sm" />
                <div className="flex-1 min-w-0">
                  <p className="font-heading font-semibold text-sm text-cw-black truncate">{m.display_name}</p>
                  <p className="font-body text-xs text-cw-stone truncate">{m.role}</p>
                </div>
                <ChevronRight className={`w-4 h-4 flex-shrink-0 transition-colors ${selectedMember?.id === m.id ? 'text-cw-coral' : 'text-cw-stone'}`} />
              </button>
            ))}
            {(squad ?? []).length === 0 && (
              <Card><EmptyState icon={<CheckCircle2 className="w-6 h-6" />} title="No team members" description="Add team members from the Squad page" /></Card>
            )}
          </div>
        </div>

        {/* Assessment form */}
        <div className="lg:col-span-2">
          {!selectedMember ? (
            <Card className="flex items-center justify-center h-64">
              <p className="font-serif italic text-cw-stone text-sm">Select a team member to begin their assessment</p>
            </Card>
          ) : (
            <Card padding="lg">
              <div className="flex items-center gap-3 mb-6 pb-5 border-b border-cw-mist">
                <Avatar initials={selectedMember.avatar_initials} color={selectedMember.avatar_color} size="lg" />
                <div>
                  <p className="font-heading font-bold text-lg text-cw-black">{selectedMember.display_name}</p>
                  <p className="font-body text-sm text-cw-stone">{selectedMember.role} · {selectedMember.venue_name}</p>
                </div>
                {saved && (
                  <div className="ml-auto flex items-center gap-1.5 text-cw-sage">
                    <CheckCircle2 className="w-4 h-4" />
                    <span className="font-heading font-semibold text-sm uppercase tracking-wide">Saved</span>
                  </div>
                )}
              </div>

              <div className="space-y-6">
                <div>
                  <div className="cw-label mb-4">Performance dimensions <span className="text-cw-stone/60 normal-case font-normal">(1 = needs development · 5 = excellent)</span></div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                    <StarRating label="Product confidence" value={form.product_confidence} onChange={v => setForm(f => ({ ...f, product_confidence: v }))} />
                    <StarRating label="Guest warmth" value={form.guest_warmth} onChange={v => setForm(f => ({ ...f, guest_warmth: v }))} />
                    <StarRating label="Table reading" value={form.table_reading} onChange={v => setForm(f => ({ ...f, table_reading: v }))} />
                    <StarRating label="Values alignment" value={form.values_alignment} onChange={v => setForm(f => ({ ...f, values_alignment: v }))} />
                  </div>
                  {form.values_alignment <= 2 && (
                    <div className="mt-3 flex items-start gap-2 p-3 bg-red-50 border border-red-200 rounded">
                      <AlertCircle className="w-4 h-4 text-cw-coral flex-shrink-0 mt-0.5" />
                      <p className="font-body text-xs text-cw-coral">Low values alignment blocks Could Say tier. The Selector takes Own It, Wow, No Dickheads and Pull Up a Chair seriously.</p>
                    </div>
                  )}
                </div>

                <div>
                  <div className="cw-label mb-3">Which tier best describes this team member this week?</div>
                  <div className="space-y-2">
                    {TIERS.map(t => (
                      <button key={t.value} onClick={() => setForm(f => ({ ...f, coaching_tier: t.value }))}
                        className={`w-full text-left p-3 rounded border-2 transition-all
                          ${form.coaching_tier === t.value ? t.color + ' border-opacity-100' : 'border-cw-mist bg-white hover:border-cw-sand'}`}>
                        <div className="flex items-center gap-3">
                          <TierBadge tier={t.value} size="sm" />
                          <span className="font-body text-xs text-cw-stone">{t.desc}</span>
                        </div>
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <div className="cw-label mb-2">Don't Say — any phrases observed this week?</div>
                  <p className="font-body text-xs text-cw-stone mb-3">Tick any you heard. The Selector uses these in the coaching narrative.</p>
                  <div className="flex flex-wrap gap-2">
                    {DONT_SAY.map(phrase => (
                      <button key={phrase} onClick={() => toggleDontSay(phrase)}
                        className={`px-3 py-1.5 rounded text-xs font-body border transition-all
                          ${form.dont_say_flags.includes(phrase) ? 'bg-cw-coral text-white border-cw-coral' : 'bg-white text-cw-stone border-cw-mist hover:border-cw-sand'}`}>
                        "{phrase}"
                      </button>
                    ))}
                  </div>
                </div>

                <Textarea label="Coaching note"
                  hint="Your observation this week. The Selector uses this to generate the AI coaching narrative."
                  rows={4} value={form.coaching_note}
                  onChange={e => setForm(f => ({ ...f, coaching_note: e.target.value }))}
                  placeholder="e.g. Marcus had a strong week — confident on the menu, good with recommendations. The one gap is wine..." />

                <div className="flex justify-end pt-2 border-t border-cw-mist">
                  <Button variant="primary" loading={saveMutation.isPending}
                    onClick={() => saveMutation.mutate()} icon={<CheckCircle2 className="w-4 h-4" />}>
                    Save assessment
                  </Button>
                </div>
              </div>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}
