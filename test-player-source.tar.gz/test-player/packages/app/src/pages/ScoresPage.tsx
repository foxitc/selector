import React, { useState } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { Trophy, RefreshCw, Building2 } from 'lucide-react';
import {
  PageHeader, Card, Avatar, TierBadge, ScoreChange,
  Button, Spinner, EmptyState, StatusBadge,
} from '../components/ui';
import { api } from '../lib/api';
import { useAuth, currentWeek, formatWeek } from '../hooks/useAuth';

interface Score {
  id: string;
  display_name: string;
  first_name: string;
  avatar_initials: string;
  avatar_color: string;
  role: string | null;
  department: string | null;
  venue_name: string;
  short_name: string;
  total_score: string;
  score_change: string | null;
  tier: string;
  programme_status: string;
  rank_in_venue: number | null;
  assessment_score: string | null;
  epos_score: string | null;
  operational_score: string | null;
}

interface VenueScore {
  venue_id: string;
  venue_name: string;
  short_name: string;
  total_score: string;
  score_change: string | null;
  league_position: number;
  members_scored: number;
  previous_score: string | null;
}

export function ScoresPage() {
  const { user } = useAuth();
  const week = currentWeek();
  const [venueFilter, setVenueFilter] = useState(user?.venueId ?? '');
  const [running, setRunning] = useState(false);

  const { data: scores, isLoading: scoresLoading, refetch } = useQuery({
    queryKey: ['scores', venueFilter, week],
    queryFn: () => api.get<Score[]>(`/scores${venueFilter ? `?venueId=${venueFilter}` : ''}${venueFilter ? `&` : '?'}weekEnding=${week}`),
  });

  const { data: league, isLoading: leagueLoading } = useQuery({
    queryKey: ['league', week],
    queryFn: () => api.get<VenueScore[]>(`/league?weekEnding=${week}`),
  });

  const { data: venues } = useQuery({
    queryKey: ['venues'],
    queryFn: () => api.get<Array<{ id: string; name: string }>>('/venues'),
    enabled: user?.role === 'admin',
  });

  const runSelector = useMutation({
    mutationFn: () => api.post('/selector/run', {}),
    onSuccess: () => { void refetch(); setRunning(false); },
  });

  return (
    <div>
      <PageHeader
        title="Scores"
        subtitle={`The Selector's view · ${formatWeek(week)}`}
        action={
          user?.role === 'admin' && (
            <Button
              variant="primary" size="sm"
              icon={<RefreshCw className={`w-3.5 h-3.5 ${runSelector.isPending ? 'animate-spin' : ''}`} />}
              loading={runSelector.isPending}
              onClick={() => runSelector.mutate()}
            >
              Run The Selector
            </Button>
          )
        }
      />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">

        {/* League table */}
        <div className="lg:col-span-1">
          <div className="cw-label mb-3 flex items-center gap-2">
            <Building2 className="w-3.5 h-3.5" />
            League table
          </div>
          <Card padding="none">
            {leagueLoading ? (
              <div className="flex justify-center py-8"><Spinner /></div>
            ) : !league?.length ? (
              <EmptyState icon={<Building2 className="w-6 h-6" />} title="No venue scores yet"
                description="Run The Selector to generate scores" />
            ) : (
              <div>
                {league.map((v, i) => (
                  <div
                    key={v.venue_id}
                    onClick={() => setVenueFilter(v.venue_id === venueFilter ? '' : v.venue_id)}
                    className={`flex items-center gap-3 px-4 py-3 cursor-pointer transition-colors border-b border-cw-mist last:border-0
                      ${venueFilter === v.venue_id ? 'bg-cw-coral/5 border-l-4 border-l-cw-coral' : 'hover:bg-cw-linen'}`}
                  >
                    <span className={`font-heading font-bold text-sm w-5 text-center ${i === 0 ? 'text-cw-coral' : 'text-cw-stone'}`}>
                      {v.league_position}
                    </span>
                    <div className="flex-1 min-w-0">
                      <p className="font-heading font-bold text-sm text-cw-black truncate">{v.venue_name}</p>
                      <p className="font-body text-xs text-cw-stone">{v.members_scored} members scored</p>
                    </div>
                    <div className="text-right">
                      <p className={`font-heading font-bold text-lg ${i === 0 ? 'text-cw-coral' : 'text-cw-black'}`}>
                        {Math.round(parseFloat(v.total_score))}
                      </p>
                      <ScoreChange change={v.score_change ? parseFloat(v.score_change) : null} />
                    </div>
                  </div>
                ))}
              </div>
            )}
          </Card>
        </div>

        {/* Member scores */}
        <div className="lg:col-span-2">
          <div className="cw-label mb-3 flex items-center gap-2">
            <Trophy className="w-3.5 h-3.5" />
            {venueFilter && league?.find(v => v.venue_id === venueFilter)
              ? `${league.find(v => v.venue_id === venueFilter)!.venue_name} — team scores`
              : 'All venues — team scores'
            }
          </div>

          <Card padding="none">
            {scoresLoading ? (
              <div className="flex justify-center py-8"><Spinner /></div>
            ) : !scores?.length ? (
              <EmptyState
                icon={<Trophy className="w-6 h-6" />}
                title="No scores this week"
                description="Complete manager assessments and run The Selector to generate scores"
              />
            ) : (
              <>
                {/* Table header */}
                <div className="grid grid-cols-12 px-4 py-2 bg-cw-black text-white text-xs font-heading font-semibold tracking-wider uppercase">
                  <div className="col-span-1">#</div>
                  <div className="col-span-4">Member</div>
                  <div className="col-span-2 hidden md:block">Venue</div>
                  <div className="col-span-2">Tier</div>
                  <div className="col-span-1 text-right">Score</div>
                  <div className="col-span-2 text-right hidden sm:block">Change</div>
                </div>

                {scores.map((s, i) => (
                  <div key={s.id} className={`grid grid-cols-12 items-center px-4 py-3 border-b border-cw-mist last:border-0 hover:bg-cw-linen transition-colors ${i === 0 ? 'bg-cw-cream' : ''}`}>
                    <div className="col-span-1">
                      <span className={`font-heading font-bold text-sm ${s.rank_in_venue === 1 ? 'text-cw-coral' : 'text-cw-stone'}`}>
                        {s.rank_in_venue ?? i + 1}
                      </span>
                    </div>
                    <div className="col-span-4 flex items-center gap-2.5 min-w-0">
                      <Avatar initials={s.avatar_initials} color={s.avatar_color} size="sm" />
                      <div className="min-w-0">
                        <p className="font-heading font-semibold text-sm text-cw-black truncate">{s.display_name}</p>
                        <p className="font-body text-xs text-cw-stone truncate">{s.role}</p>
                      </div>
                    </div>
                    <div className="col-span-2 hidden md:block">
                      <span className="font-heading text-xs text-cw-stone">{s.short_name}</span>
                    </div>
                    <div className="col-span-2">
                      <TierBadge tier={s.tier} size="sm" />
                    </div>
                    <div className="col-span-1 text-right">
                      <span className={`font-heading font-bold text-lg ${s.rank_in_venue === 1 ? 'text-cw-coral' : 'text-cw-black'}`}>
                        {Math.round(parseFloat(s.total_score))}
                      </span>
                    </div>
                    <div className="col-span-2 text-right hidden sm:block">
                      <ScoreChange change={s.score_change ? parseFloat(s.score_change) : null} />
                    </div>
                  </div>
                ))}
              </>
            )}
          </Card>
        </div>
      </div>
    </div>
  );
}
