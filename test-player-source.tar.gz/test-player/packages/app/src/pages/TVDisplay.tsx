import React, { useEffect, useState, useCallback } from 'react';

interface DisplayData {
  venue: { id: string; name: string; shortName: string };
  weekEnding: string;
  themeConfig: ThemeConfig;
  members: MemberScore[];
  venueScore: VenueScore | null;
  league: LeagueRow[];
  focusMessage: string | null;
}

interface ThemeConfig {
  accentColor: string;
  backgroundColor: string;
  fontFamily?: string;
  borderRadius?: 'sharp' | 'rounded' | 'pill';
}

interface MemberScore {
  display_name: string;
  avatar_initials: string;
  avatar_color: string;
  role: string | null;
  total_score: string;
  score_change: string | null;
  tier: string;
  programme_status: string;
  rank_in_venue: number | null;
  coaching_narrative: string | null;
}

interface VenueScore {
  total_score: string;
  score_change: string | null;
  league_position: number | null;
  members_scored: number;
}

interface LeagueRow {
  venue_name: string;
  short_name: string;
  total_score: string;
  score_change: string | null;
  league_position: number;
}

const RADIUS = { sharp: '0px', rounded: '8px', pill: '20px' };

const TIER_STYLES: Record<string, { bg: string; text: string }> = {
  'could-say':  { bg: '#9db3c1', text: '#fff' },
  'should-say': { bg: '#6e9277', text: '#fff' },
  'have-to':    { bg: '#e5ba96', text: '#1c1c1c' },
  'review':     { bg: '#fd6f53', text: '#fff' },
};

const TIER_LABELS: Record<string, string> = {
  'could-say':  'Could Say',
  'should-say': 'Should Say',
  'have-to':    'Have To',
  'review':     'Review',
};

function isDark(hex: string): boolean {
  const r = parseInt(hex.slice(1,3),16), g = parseInt(hex.slice(3,5),16), b = parseInt(hex.slice(5,7),16);
  return (r*299 + g*587 + b*114)/1000 < 128;
}

export function TVDisplay() {
  const token = window.location.pathname.split('/display/')[1]?.split('/')[0] ?? '';
  const [data, setData] = useState<DisplayData | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [lastUpdated, setLastUpdated] = useState<Date | null>(null);
  const [offline, setOffline] = useState(false);

  const fetchData = useCallback(async () => {
    try {
      const res = await fetch(`/api/v1/display/${token}`);
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const json = await res.json() as { data: DisplayData; error: null };
      setData(json.data);
      setLastUpdated(new Date());
      setOffline(false);
    } catch (err) {
      setOffline(true);
      if (!data) setError(err instanceof Error ? err.message : 'Connection failed');
    }
  }, [token, data]);

  useEffect(() => {
    if (!token) return;
    void fetchData();
    const id = setInterval(() => void fetchData(), 60_000);
    return () => clearInterval(id);
  }, [fetchData, token]);

  if (!token) return <Fullscreen bg="#1c1c1c"><p style={{ color: '#a8a28a', fontFamily: 'monospace', fontSize: 13 }}>No display token</p></Fullscreen>;
  if (!data && !error) return <LoadingScreen />;
  if (!data && error) return <ErrorScreen message={error} />;

  const theme = data!.themeConfig ?? { accentColor: '#fd6f53', backgroundColor: '#1c1c1c' };
  const dark = isDark(theme.backgroundColor);
  const a = theme.accentColor;
  const r = RADIUS[theme.borderRadius ?? 'sharp'];
  const col = {
    text:       dark ? '#ffffff' : '#1c1c1c',
    textMuted:  dark ? 'rgba(255,255,255,0.55)' : 'rgba(0,0,0,0.55)',
    textDim:    dark ? 'rgba(255,255,255,0.25)' : 'rgba(0,0,0,0.25)',
    cardBg:     dark ? 'rgba(255,255,255,0.04)' : 'rgba(0,0,0,0.04)',
    cardBorder: dark ? 'rgba(255,255,255,0.09)' : 'rgba(0,0,0,0.12)',
    divider:    dark ? 'rgba(255,255,255,0.07)' : 'rgba(0,0,0,0.07)',
    barBg:      dark ? 'rgba(255,255,255,0.08)' : 'rgba(0,0,0,0.08)',
  };

  const { venue, members, venueScore, league, focusMessage } = data!;
  const timeStr = lastUpdated?.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' }) ?? '--:--';

  return (
    <Fullscreen bg={theme.backgroundColor}>
      <div style={{ padding: '28px 32px', display: 'flex', flexDirection: 'column', height: '100%', fontFamily: '"Barlow Condensed", system-ui, sans-serif', color: col.text }}>

        {/* Header */}
        <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: 24 }}>
          <div>
            <div style={{ fontSize: 11, fontWeight: 700, letterSpacing: '0.18em', textTransform: 'uppercase', color: a, marginBottom: 3 }}>
              {venue.shortName}
            </div>
            <div style={{ fontFamily: '"Playfair Display", Georgia, serif', fontSize: 32, fontWeight: 700, fontStyle: 'italic', color: col.text, lineHeight: 1 }}>
              Test Player
            </div>
            <div style={{ fontSize: 10, fontWeight: 600, letterSpacing: '0.14em', textTransform: 'uppercase', color: col.textDim, marginTop: 3 }}>
              The Selector · week ending {data!.weekEnding}
            </div>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            {offline && (
              <div style={{ display: 'flex', alignItems: 'center', gap: 5, padding: '4px 10px', borderRadius: 20, background: 'rgba(253,111,83,0.15)', border: '1px solid rgba(253,111,83,0.3)' }}>
                <div style={{ width: 5, height: 5, borderRadius: '50%', background: '#fd6f53' }} />
                <span style={{ fontSize: 9, color: '#fd6f53', fontWeight: 700, letterSpacing: '0.08em' }}>OFFLINE</span>
              </div>
            )}
            <div style={{ display: 'flex', alignItems: 'center', gap: 5, padding: '5px 11px', borderRadius: 20, background: `${a}18`, border: `1px solid ${a}35` }}>
              <div style={{ width: 5, height: 5, borderRadius: '50%', background: a, animation: 'pulse 2s infinite' }} />
              <span style={{ fontSize: 9, fontWeight: 700, color: a, letterSpacing: '0.08em' }}>LIVE</span>
            </div>
          </div>
        </div>

        {/* Main grid */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 260px', gap: 24, flex: 1, minHeight: 0 }}>

          {/* Left — hero + leaderboard */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 18 }}>

            {/* Venue hero score */}
            {venueScore && (
              <div style={{ background: col.cardBg, border: `1px solid ${col.cardBorder}`, borderRadius: r, padding: '18px 22px' }}>
                <div style={{ fontSize: 10, fontWeight: 600, letterSpacing: '0.14em', textTransform: 'uppercase', color: col.textDim, marginBottom: 8 }}>
                  Team score this week
                </div>
                <div style={{ display: 'flex', alignItems: 'flex-end', gap: 16, marginBottom: 10 }}>
                  <div style={{ fontSize: 72, fontWeight: 800, color: a, lineHeight: 1, letterSpacing: -2 }}>
                    {Math.round(parseFloat(venueScore.total_score))}
                  </div>
                  <div style={{ paddingBottom: 8 }}>
                    {venueScore.score_change !== null && (
                      <div style={{ fontSize: 16, fontWeight: 700, color: parseFloat(venueScore.score_change ?? '0') >= 0 ? '#6e9277' : '#fd6f53', marginBottom: 4 }}>
                        {parseFloat(venueScore.score_change ?? '0') >= 0 ? '+' : ''}{parseFloat(venueScore.score_change ?? '0').toFixed(1)} this week
                      </div>
                    )}
                    {venueScore.league_position && (
                      <div style={{ fontFamily: '"Playfair Display", serif', fontSize: 12, fontStyle: 'italic', color: col.textDim }}>
                        {venueScore.league_position === 1 ? 'Leading the league' : `${venueScore.league_position}${['','st','nd','rd'][venueScore.league_position] ?? 'th'} of ${league.length}`}
                      </div>
                    )}
                  </div>
                </div>
                <div style={{ height: 4, background: col.barBg, borderRadius: 2, overflow: 'hidden' }}>
                  <div style={{ width: `${parseFloat(venueScore.total_score)}%`, height: '100%', background: a, borderRadius: 2 }} />
                </div>
              </div>
            )}

            {/* Member leaderboard */}
            <div style={{ background: col.cardBg, border: `1px solid ${col.cardBorder}`, borderRadius: r, overflow: 'hidden', flex: 1 }}>
              <div style={{ padding: '12px 18px', borderBottom: `1px solid ${col.divider}`, fontSize: 9, fontWeight: 700, letterSpacing: '0.14em', textTransform: 'uppercase', color: col.textDim }}>
                The Selector's view this week
              </div>
              {members.length === 0 ? (
                <div style={{ padding: 32, textAlign: 'center', color: col.textDim, fontSize: 13, fontFamily: '"Playfair Display", serif', fontStyle: 'italic' }}>
                  The Selector hasn't assessed this week yet
                </div>
              ) : (
                members.map((m, i) => {
                  const tierStyle = TIER_STYLES[m.tier] ?? { bg: '#a8a28a', text: '#fff' };
                  return (
                    <div key={`${m.display_name}-${i}`} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '12px 18px', borderBottom: `1px solid ${col.divider}` }}>
                      <span style={{ width: 22, textAlign: 'center', fontSize: i === 0 ? 16 : 12, fontWeight: 700, color: i === 0 ? a : col.textDim, flexShrink: 0 }}>
                        {m.rank_in_venue ?? i + 1}
                      </span>
                      <div style={{ width: 36, height: 36, borderRadius: '50%', background: m.avatar_color, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 11, fontWeight: 700, color: '#fff', flexShrink: 0 }}>
                        {m.avatar_initials}
                      </div>
                      <div style={{ flex: 1, minWidth: 0 }}>
                        <div style={{ fontSize: i === 0 ? 16 : 14, fontWeight: 600, color: col.text, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{m.display_name}</div>
                        {m.role && <div style={{ fontSize: 10, color: col.textDim, textTransform: 'uppercase', letterSpacing: '0.06em', marginTop: 1 }}>{m.role}</div>}
                      </div>
                      <div style={{ padding: '2px 8px', borderRadius: r, background: tierStyle.bg, color: tierStyle.text, fontSize: 9, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.08em', flexShrink: 0 }}>
                        {TIER_LABELS[m.tier] ?? m.tier}
                      </div>
                      <div style={{ fontSize: i === 0 ? 28 : 20, fontWeight: 800, color: i === 0 ? a : col.text, flexShrink: 0, minWidth: 40, textAlign: 'right' }}>
                        {Math.round(parseFloat(m.total_score))}
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>

          {/* Right — league + focus */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 18 }}>
            {/* League */}
            <div style={{ background: col.cardBg, border: `1px solid ${col.cardBorder}`, borderRadius: r, overflow: 'hidden' }}>
              <div style={{ padding: '12px 16px', borderBottom: `1px solid ${col.divider}`, fontSize: 9, fontWeight: 700, letterSpacing: '0.14em', textTransform: 'uppercase', color: col.textDim }}>
                League
              </div>
              {league.map((v, i) => {
                const isCurrent = v.venue_name === venue.name;
                return (
                  <div key={v.venue_name} style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '11px 16px', borderBottom: `1px solid ${col.divider}`, background: isCurrent ? `${a}12` : 'transparent', borderLeft: `3px solid ${isCurrent ? a : 'transparent'}` }}>
                    <span style={{ width: 16, fontSize: 11, fontWeight: 700, color: i === 0 ? a : col.textDim }}>{v.league_position}</span>
                    <span style={{ flex: 1, fontSize: 13, fontWeight: isCurrent ? 700 : 400, color: isCurrent ? col.text : col.textMuted, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                      {v.venue_name}
                    </span>
                    <span style={{ fontSize: 16, fontWeight: 800, color: isCurrent ? a : col.textMuted }}>
                      {Math.round(parseFloat(v.total_score))}
                    </span>
                    {v.score_change !== null && (
                      <span style={{ fontSize: 10, fontWeight: 700, color: parseFloat(v.score_change ?? '0') >= 0 ? '#6e9277' : '#fd6f53', width: 32, textAlign: 'right', flexShrink: 0 }}>
                        {parseFloat(v.score_change ?? '0') >= 0 ? '+' : ''}{parseFloat(v.score_change ?? '0').toFixed(1)}
                      </span>
                    )}
                  </div>
                );
              })}
            </div>

            {/* Focus message */}
            {focusMessage && (
              <div style={{ background: `${a}12`, border: `1px solid ${a}30`, borderRadius: r, padding: '14px 16px' }}>
                <div style={{ fontSize: 9, fontWeight: 700, letterSpacing: '0.14em', textTransform: 'uppercase', color: a, marginBottom: 6 }}>
                  The Coach's focus this week
                </div>
                <div style={{ fontFamily: '"Playfair Display", Georgia, serif', fontSize: 14, fontStyle: 'italic', color: col.textMuted, lineHeight: 1.6 }}>
                  "{focusMessage}"
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 18, paddingTop: 14, borderTop: `1px solid ${col.divider}` }}>
          <span style={{ fontSize: 10, color: col.textDim }}>The Selector · updated {timeStr} · Cat &amp; Wickets</span>
          <span style={{ fontFamily: '"Playfair Display", serif', fontSize: 11, fontStyle: 'italic', color: col.textDim }}>Test Player</span>
        </div>
      </div>

      <style>{`
        @keyframes pulse { 0%,100%{opacity:1} 50%{opacity:.3} }
        * { box-sizing: border-box; margin: 0; padding: 0; }
      `}</style>
    </Fullscreen>
  );
}

function Fullscreen({ bg, children }: { bg: string; children: React.ReactNode }) {
  return (
    <div style={{ width: '100vw', height: '100vh', background: bg, overflow: 'hidden', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
      <div style={{ width: '100%', height: '100%' }}>{children}</div>
    </div>
  );
}

function LoadingScreen() {
  return (
    <Fullscreen bg="#1c1c1c">
      <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 16, color: '#a8a28a' }}>
        <div style={{ width: 36, height: 36, borderRadius: '50%', border: '2px solid #fd6f53', borderTopColor: 'transparent', animation: 'spin 0.8s linear infinite' }} />
        <p style={{ fontFamily: '"Barlow Condensed", sans-serif', fontSize: 11, letterSpacing: '0.14em', textTransform: 'uppercase' }}>Connecting to The Selector</p>
      </div>
      <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
    </Fullscreen>
  );
}

function ErrorScreen({ message }: { message: string }) {
  return (
    <Fullscreen bg="#1c1c1c">
      <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 10 }}>
        <p style={{ color: '#a8a28a', fontFamily: '"Barlow Condensed", sans-serif', fontSize: 13 }}>Unable to connect to Test Player</p>
        <p style={{ color: '#6b6b6b', fontFamily: 'monospace', fontSize: 11 }}>{message}</p>
      </div>
    </Fullscreen>
  );
}
