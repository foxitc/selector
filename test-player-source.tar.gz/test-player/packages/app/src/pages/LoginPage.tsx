import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { AlertCircle } from 'lucide-react';
import { Button, Input } from '../components/ui';
import { api, setToken } from '../lib/api';
import { useAuth } from '../hooks/useAuth';

interface LoginResponse {
  token: string;
  user: { id: string; email: string; firstName: string; lastName: string; role: 'admin' | 'coach' | 'viewer'; venueId: string | null };
}

export function LoginPage() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();
  const { setUser } = useAuth();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      const res = await api.post<LoginResponse>('/auth/login', { email, password });
      setToken(res.token);
      setUser(res.user);
      navigate('/squad');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Login failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-cw-black flex items-center justify-center p-4">
      <div className="w-full max-w-sm">
        {/* Brand */}
        <div className="text-center mb-8">
          <div className="font-heading text-xs font-bold tracking-widest uppercase text-cw-coral mb-2">
            Cat &amp; Wickets
          </div>
          <h1 className="font-serif italic text-white text-4xl mb-1">Test Player</h1>
          <p className="font-heading text-xs tracking-wider uppercase text-cw-stone">
            Hospitality development programme
          </p>
        </div>

        <div className="bg-white rounded-lg overflow-hidden">
          <div className="bg-cw-black px-5 py-3 border-b border-white/10">
            <p className="font-heading font-bold text-xs tracking-wider uppercase text-white">
              Sign in to The Club
            </p>
          </div>
          <div className="p-5">
            {error && (
              <div className="flex items-center gap-2 p-3 bg-red-50 border border-red-200 rounded mb-4">
                <AlertCircle className="w-4 h-4 text-cw-coral flex-shrink-0" />
                <p className="font-body text-sm text-cw-coral">{error}</p>
              </div>
            )}
            <form onSubmit={handleSubmit} className="space-y-4">
              <Input label="Email address" type="email" value={email}
                onChange={e => setEmail(e.target.value)} autoComplete="email" required />
              <Input label="Password" type="password" value={password}
                onChange={e => setPassword(e.target.value)} autoComplete="current-password" required />
              <Button type="submit" variant="primary" className="w-full" loading={loading}>
                Sign in
              </Button>
            </form>
          </div>
        </div>

        <p className="text-center font-heading text-xs tracking-wider text-cw-stone/40 mt-6 uppercase">
          Powered by The Selector
        </p>
      </div>
    </div>
  );
}
