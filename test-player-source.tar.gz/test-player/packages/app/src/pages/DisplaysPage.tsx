import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Tv, Copy, Check, Plus, Palette, ExternalLink } from 'lucide-react';
import { PageHeader, Card, Button, Input, Spinner, EmptyState, Modal } from '../components/ui';
import { api } from '../lib/api';

interface DisplayToken {
  id: string;
  venue_id: string;
  venue_name: string;
  short_name: string;
  token: string;
  display_type: string;
  is_active: boolean;
  last_accessed: string | null;
  theme_config: ThemeConfig;
  created_at: string;
}

interface ThemeConfig {
  accentColor: string;
  backgroundColor: string;
  fontFamily: string;
  borderRadius: 'sharp' | 'rounded' | 'pill';
}

interface Venue { id: string; name: string; short_name: string; }

const DEFAULT_THEME: ThemeConfig = {
  accentColor:     '#fd6f53',
  backgroundColor: '#1c1c1c',
  fontFamily:      'Barlow Condensed',
  borderRadius:    'sharp',
};

const CW_COLOURS = ['#fd6f53','#6e9277','#9db3c1','#e5ba96','#b38b6d','#a8a28a','#1c1c1c','#ffffff'];

export function DisplaysPage() {
  const qc = useQueryClient();
  const [showCreate, setShowCreate] = useState(false);
  const [editTheme, setEditTheme] = useState<DisplayToken | null>(null);
  const [copied, setCopied] = useState<string | null>(null);

  const { data: tokens, isLoading } = useQuery({
    queryKey: ['display-tokens'],
    queryFn: () => api.get<DisplayToken[]>('/display-tokens'),
  });

  const copyUrl = async (token: string) => {
    await navigator.clipboard.writeText(`${window.location.origin}/display/${token}`);
    setCopied(token);
    setTimeout(() => setCopied(null), 2000);
  };

  return (
    <div>
      <PageHeader
        title="Displays"
        subtitle="TV display links for each venue"
        action={
          <Button variant="primary" size="sm" icon={<Plus className="w-3.5 h-3.5" />} onClick={() => setShowCreate(true)}>
            Create display
          </Button>
        }
      />

      {isLoading ? (
        <div className="flex justify-center py-16"><Spinner className="w-6 h-6" /></div>
      ) : !tokens?.length ? (
        <Card>
          <EmptyState
            icon={<Tv className="w-8 h-8" />}
            title="No displays configured"
            description="Create a display link for each venue TV screen"
            action={<Button variant="primary" size="sm" onClick={() => setShowCreate(true)}>Create display</Button>}
          />
        </Card>
      ) : (
        <div className="space-y-3">
          {tokens.map(t => (
            <Card key={t.id} padding="none">
              <div className="flex items-center gap-4 px-5 py-4">
                {/* Colour preview */}
                <div className="w-10 h-10 rounded flex-shrink-0 border border-cw-mist overflow-hidden"
                  style={{ background: t.theme_config?.backgroundColor ?? '#1c1c1c' }}>
                  <div className="w-full h-2 mt-3" style={{ background: t.theme_config?.accentColor ?? '#fd6f53' }} />
                </div>

                <div className="flex-1 min-w-0">
                  <p className="font-heading font-bold text-sm text-cw-black">{t.venue_name}</p>
                  <p className="font-body text-xs text-cw-stone font-mono truncate">
                    {window.location.origin}/display/{t.token.slice(0, 16)}...
                  </p>
                  {t.last_accessed && (
                    <p className="font-body text-xs text-cw-stone/60 mt-0.5">
                      Last viewed: {new Date(t.last_accessed).toLocaleString('en-GB', { dateStyle: 'short', timeStyle: 'short' })}
                    </p>
                  )}
                </div>

                <div className="flex items-center gap-2 flex-shrink-0">
                  <Button variant="ghost" size="sm" icon={<Palette className="w-3.5 h-3.5" />}
                    onClick={() => setEditTheme(t)}>Theme</Button>
                  <Button variant="ghost" size="sm" icon={<ExternalLink className="w-3.5 h-3.5" />}
                    onClick={() => window.open(`/display/${t.token}`, '_blank')}>Preview</Button>
                  <Button
                    variant="secondary" size="sm"
                    icon={copied === t.token ? <Check className="w-3.5 h-3.5 text-cw-sage" /> : <Copy className="w-3.5 h-3.5" />}
                    onClick={() => copyUrl(t.token)}
                  >
                    {copied === t.token ? 'Copied' : 'Copy URL'}
                  </Button>
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}

      <CreateDisplayModal
        open={showCreate}
        onClose={() => setShowCreate(false)}
        onSaved={() => { setShowCreate(false); void qc.invalidateQueries({ queryKey: ['display-tokens'] }); }}
      />

      {editTheme && (
        <ThemeModal
          token={editTheme}
          onClose={() => setEditTheme(null)}
          onSaved={() => { setEditTheme(null); void qc.invalidateQueries({ queryKey: ['display-tokens'] }); }}
        />
      )}
    </div>
  );
}

function CreateDisplayModal({ open, onClose, onSaved }: {
  open: boolean; onClose: () => void; onSaved: () => void;
}) {
  const [venueId, setVenueId] = useState('');

  const { data: venues } = useQuery({
    queryKey: ['venues'],
    queryFn: () => api.get<Venue[]>('/venues'),
  });

  const mutation = useMutation({
    mutationFn: () => api.post('/display-tokens', { venueId, themeConfig: DEFAULT_THEME }),
    onSuccess: onSaved,
  });

  return (
    <Modal open={open} onClose={onClose} title="Create display" subtitle="Generate a TV display link for a venue">
      <div className="space-y-4">
        <div className="space-y-1">
          <label className="cw-label block">Venue</label>
          <select
            value={venueId}
            onChange={e => setVenueId(e.target.value)}
            className="w-full h-9 px-3 text-sm border border-cw-mist rounded bg-white font-body focus:outline-none"
          >
            <option value="">Select venue...</option>
            {(venues ?? []).map(v => <option key={v.id} value={v.id}>{v.name}</option>)}
          </select>
        </div>
        <div className="p-3 bg-cw-linen rounded border border-cw-sand text-xs font-body text-cw-stone">
          The display URL requires no login. Share it with the TV browser. Revoke it any time by deleting the display.
        </div>
        <div className="flex justify-end gap-2 pt-2 border-t border-cw-mist">
          <Button variant="ghost" onClick={onClose}>Cancel</Button>
          <Button variant="primary" loading={mutation.isPending} disabled={!venueId} onClick={() => mutation.mutate()}>
            Create display
          </Button>
        </div>
      </div>
    </Modal>
  );
}

function ThemeModal({ token, onClose, onSaved }: {
  token: DisplayToken; onClose: () => void; onSaved: () => void;
}) {
  const [theme, setTheme] = useState<ThemeConfig>(token.theme_config ?? DEFAULT_THEME);

  const mutation = useMutation({
    mutationFn: () => api.put(`/display-tokens/${token.id}`, { themeConfig: theme }),
    onSuccess: onSaved,
  });

  const isDark = (hex: string) => {
    const r = parseInt(hex.slice(1,3),16), g = parseInt(hex.slice(3,5),16), b = parseInt(hex.slice(5,7),16);
    return (r*299 + g*587 + b*114)/1000 < 128;
  };

  return (
    <Modal open onClose={onClose} title={`Theme — ${token.venue_name}`} subtitle="Displayed on the pub TV screen" maxWidth="lg">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Controls */}
        <div className="space-y-5">
          <div>
            <div className="cw-label mb-2">Accent colour</div>
            <div className="flex gap-2 flex-wrap">
              {CW_COLOURS.map(c => (
                <button key={c} onClick={() => setTheme(t => ({ ...t, accentColor: c }))}
                  className={`w-7 h-7 rounded transition-transform hover:scale-110 ${theme.accentColor === c ? 'ring-2 ring-offset-2 ring-cw-black' : ''}`}
                  style={{ background: c, border: c === '#ffffff' ? '1px solid #e0e6e9' : 'none' }} />
              ))}
            </div>
            <Input className="mt-2 font-mono text-xs" value={theme.accentColor}
              onChange={e => /^#[0-9a-fA-F]{0,6}$/.test(e.target.value) && setTheme(t => ({ ...t, accentColor: e.target.value }))} />
          </div>

          <div>
            <div className="cw-label mb-2">Background</div>
            <div className="flex gap-2 flex-wrap">
              {['#1c1c1c','#0a0a0a','#111827','#1e1b4b','#0f172a','#fff5d6','#f5e5cf','#ffffff'].map(c => (
                <button key={c} onClick={() => setTheme(t => ({ ...t, backgroundColor: c }))}
                  className={`w-7 h-7 rounded transition-transform hover:scale-110 ${theme.backgroundColor === c ? 'ring-2 ring-offset-2 ring-cw-black' : ''}`}
                  style={{ background: c, border: ['#ffffff','#f5e5cf','#fff5d6'].includes(c) ? '1px solid #e0e6e9' : 'none' }} />
              ))}
            </div>
          </div>

          <div>
            <div className="cw-label mb-2">Corner style</div>
            <div className="flex gap-2">
              {(['sharp','rounded','pill'] as const).map(r => (
                <button key={r} onClick={() => setTheme(t => ({ ...t, borderRadius: r }))}
                  className={`flex-1 py-1.5 text-xs font-heading font-semibold uppercase tracking-wide border rounded transition-all
                    ${theme.borderRadius === r ? 'bg-cw-coral text-white border-cw-coral' : 'bg-white text-cw-stone border-cw-mist hover:border-cw-sand'}`}>
                  {r}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Mini preview */}
        <div>
          <div className="cw-label mb-2">Preview</div>
          <div className="rounded overflow-hidden" style={{ background: theme.backgroundColor, padding: 16, minHeight: 200 }}>
            <div style={{ fontSize: 9, fontWeight: 700, letterSpacing: '0.18em', textTransform: 'uppercase', color: theme.accentColor, marginBottom: 3 }}>
              {token.venue_name}
            </div>
            <div style={{ fontFamily: "'Playfair Display', serif", fontSize: 18, fontWeight: 700, fontStyle: 'italic', color: isDark(theme.backgroundColor) ? '#fff' : '#1c1c1c', marginBottom: 12 }}>
              Test Player
            </div>
            {[{ name: 'Marcus Bennett', score: 94, tier: 'Could Say', color: '#fd6f53' },
              { name: 'Amy Chen',       score: 91, tier: 'Should Say', color: '#9db3c1' },
              { name: 'Darren Walsh',   score: 88, tier: 'Should Say', color: '#b38b6d' }].map((m, i) => (
              <div key={m.name} style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '6px 0', borderBottom: `1px solid ${isDark(theme.backgroundColor) ? 'rgba(255,255,255,.06)' : 'rgba(0,0,0,.06)'}` }}>
                <span style={{ width: 14, fontSize: 10, fontWeight: 700, color: i === 0 ? theme.accentColor : isDark(theme.backgroundColor) ? 'rgba(255,255,255,.3)' : 'rgba(0,0,0,.3)' }}>{i+1}</span>
                <div style={{ width: 22, height: 22, borderRadius: '50%', background: m.color, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 8, fontWeight: 700, color: '#fff', flexShrink: 0 }}>
                  {m.name.split(' ').map(n => n[0]).join('')}
                </div>
                <span style={{ flex: 1, fontSize: 11, color: isDark(theme.backgroundColor) ? '#fff' : '#1c1c1c' }}>{m.name}</span>
                <span style={{ fontSize: 8, padding: '1px 5px', borderRadius: theme.borderRadius === 'pill' ? 10 : theme.borderRadius === 'rounded' ? 3 : 0, background: i === 0 ? '#9db3c1' : '#6e9277', color: '#fff', fontWeight: 700, textTransform: 'uppercase' }}>{m.tier}</span>
                <span style={{ fontSize: 14, fontWeight: 800, color: i === 0 ? theme.accentColor : isDark(theme.backgroundColor) ? '#fff' : '#1c1c1c' }}>{m.score}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="flex justify-end gap-2 mt-5 pt-4 border-t border-cw-mist">
        <Button variant="ghost" onClick={onClose}>Cancel</Button>
        <Button variant="primary" loading={mutation.isPending} icon={<Palette className="w-3.5 h-3.5" />} onClick={() => mutation.mutate()}>
          Save theme
        </Button>
      </div>
    </Modal>
  );
}
