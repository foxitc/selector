import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Users, Plus, Search, ChevronRight } from 'lucide-react';
import {
  PageHeader, Card, Avatar, TierBadge, StatusBadge, ScoreChange,
  Button, EmptyState, Spinner, Modal, Input,
} from '../components/ui';
import { api } from '../lib/api';
import { useAuth, currentWeek, formatWeek } from '../hooks/useAuth';

interface Member {
  id: string;
  display_name: string;
  first_name: string;
  avatar_initials: string;
  avatar_color: string;
  role: string | null;
  department: string | null;
  venue_name: string;
  venue_short_name: string;
  selector_tier: string | null;
  selector_status: string | null;
  selector_score: string | null;
  total_score: string | null;
  score_change: string | null;
  tier: string | null;
  programme_status: string | null;
  rank_in_venue: number | null;
  coaching_narrative: string | null;
}

interface Venue {
  id: string;
  name: string;
  short_name: string;
}

export function SquadPage() {
  const { user } = useAuth();
  const week = currentWeek();
  const [venueFilter, setVenueFilter] = useState(user?.venueId ?? '');
  const [search, setSearch] = useState('');
  const [selectedMember, setSelectedMember] = useState<Member | null>(null);
  const [showAdd, setShowAdd] = useState(false);

  const { data: venues } = useQuery({
    queryKey: ['venues'],
    queryFn: () => api.get<Venue[]>('/venues'),
  });

  const { data: squad, isLoading } = useQuery({
    queryKey: ['squad', venueFilter, week],
    queryFn: () => api.get<Member[]>(`/squad${venueFilter ? `?venueId=${venueFilter}` : ''}`),
  });

  const filtered = (squad ?? []).filter(m =>
    !search || m.display_name.toLowerCase().includes(search.toLowerCase()),
  );

  const onProgramme = filtered.filter(m => m.programme_status === 'on-programme' || m.tier === 'could-say' || m.tier === 'should-say');
  const notYet      = filtered.filter(m => m.programme_status === 'not-yet' || m.tier === 'have-to');
  const underReview = filtered.filter(m => m.programme_status === 'under-review' || m.tier === 'review');

  return (
    <div>
      <PageHeader
        title="The Squad"
        subtitle={`Week ending ${formatWeek(week)}`}
        action={
          user?.role === 'admin' && (
            <Button variant="primary" size="sm" icon={<Plus className="w-3.5 h-3.5" />} onClick={() => setShowAdd(true)}>
              Add member
            </Button>
          )
        }
      />

      {/* Filters */}
      <div className="flex gap-3 mb-5 flex-wrap">
        <div className="relative flex-1 min-w-48">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-cw-stone" />
          <input
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Search squad..."
            className="w-full h-9 pl-9 pr-3 text-sm border border-cw-mist rounded bg-white font-body focus:outline-none focus:ring-1 focus:border-cw-sand"
          />
        </div>
        {user?.role === 'admin' && (
          <select
            value={venueFilter}
            onChange={e => setVenueFilter(e.target.value)}
            className="h-9 px-3 text-sm border border-cw-mist rounded bg-white font-body focus:outline-none"
          >
            <option value="">All venues</option>
            {(venues ?? []).map(v => <option key={v.id} value={v.id}>{v.name}</option>)}
          </select>
        )}
      </div>

      {isLoading ? (
        <div className="flex justify-center py-16"><Spinner className="w-6 h-6" /></div>
      ) : filtered.length === 0 ? (
        <Card>
          <EmptyState icon={<Users className="w-8 h-8" />} title="No squad members found"
            description="Add team members to start tracking performance with The Selector" />
        </Card>
      ) : (
        <div className="space-y-6">
          {/* On Programme */}
          {onProgramme.length > 0 && (
            <section>
              <div className="cw-label mb-3 flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-cw-sage" />
                On programme ({onProgramme.length})
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-3">
                {onProgramme.map(m => <MemberCard key={m.id} member={m} onClick={() => setSelectedMember(m)} />)}
              </div>
            </section>
          )}

          {/* Have To */}
          {notYet.length > 0 && (
            <section>
              <div className="cw-label mb-3 flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-cw-sand" />
                Developing ({notYet.length})
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-3">
                {notYet.map(m => <MemberCard key={m.id} member={m} onClick={() => setSelectedMember(m)} />)}
              </div>
            </section>
          )}

          {/* Under Review */}
          {underReview.length > 0 && (
            <section>
              <div className="cw-label mb-3 flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-cw-coral" />
                Under review ({underReview.length})
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-3">
                {underReview.map(m => <MemberCard key={m.id} member={m} onClick={() => setSelectedMember(m)} />)}
              </div>
            </section>
          )}
        </div>
      )}

      {/* Member detail modal */}
      <Modal
        open={!!selectedMember}
        onClose={() => setSelectedMember(null)}
        title={selectedMember?.display_name ?? ''}
        subtitle={selectedMember?.role ?? undefined}
        maxWidth="lg"
      >
        {selectedMember && <MemberDetail member={selectedMember} />}
      </Modal>
    </div>
  );
}

function MemberCard({ member, onClick }: { member: Member; onClick: () => void }) {
  const score = member.total_score ? parseFloat(member.total_score) : null;
  const change = member.score_change ? parseFloat(member.score_change) : null;
  const tier = member.tier ?? member.selector_tier;
  const status = member.programme_status ?? member.selector_status;

  return (
    <button
      onClick={onClick}
      className="cw-card p-4 text-left w-full hover:border-cw-sand transition-colors group"
    >
      <div className="flex items-start justify-between gap-3">
        <div className="flex items-center gap-3 min-w-0">
          <Avatar initials={member.avatar_initials} color={member.avatar_color} size="md" />
          <div className="min-w-0">
            <p className="font-heading font-bold text-sm text-cw-black truncate">{member.display_name}</p>
            <p className="font-body text-xs text-cw-stone truncate">{member.role}</p>
            <p className="font-heading text-xs text-cw-stone/60 tracking-wide">{member.venue_short_name}</p>
          </div>
        </div>
        <div className="flex flex-col items-end gap-1.5 flex-shrink-0">
          {score !== null && (
            <span className="font-heading font-bold text-xl text-cw-black">{Math.round(score)}</span>
          )}
          {change !== null && <ScoreChange change={change} />}
        </div>
      </div>

      <div className="flex items-center justify-between mt-3 pt-3 border-t border-cw-mist">
        <div className="flex gap-1.5">
          {tier && <TierBadge tier={tier} size="sm" />}
          {status && <StatusBadge status={status} />}
        </div>
        <ChevronRight className="w-4 h-4 text-cw-stone group-hover:text-cw-coral transition-colors" />
      </div>
    </button>
  );
}

function MemberDetail({ member }: { member: Member }) {
  const score = member.total_score ? parseFloat(member.total_score) : null;
  const tier = member.tier ?? member.selector_tier;
  const status = member.programme_status ?? member.selector_status;

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex items-center gap-4">
        <Avatar initials={member.avatar_initials} color={member.avatar_color} size="lg" />
        <div>
          <p className="font-heading font-bold text-lg text-cw-black">{member.display_name}</p>
          <p className="font-body text-sm text-cw-stone">{member.role} · {member.venue_name}</p>
          <div className="flex gap-2 mt-1.5">
            {tier && <TierBadge tier={tier} />}
            {status && <StatusBadge status={status} />}
          </div>
        </div>
        {score !== null && (
          <div className="ml-auto text-right">
            <div className="font-heading font-bold text-4xl text-cw-coral">{Math.round(score)}</div>
            <div className="cw-label">This week</div>
          </div>
        )}
      </div>

      {/* Score breakdown */}
      {(member.total_score) && (
        <div>
          <div className="cw-label mb-3">The Selector's breakdown</div>
          <div className="grid grid-cols-3 gap-3">
            {[
              { label: 'Manager assessment', key: 'assessment_score', weight: '40%', color: 'bg-cw-coral' },
              { label: 'EPOS signals', key: 'epos_score', weight: '40%', color: 'bg-cw-slate' },
              { label: 'Operational', key: 'operational_score', weight: '20%', color: 'bg-cw-sage' },
            ].map(item => {
              const val = (member as unknown as Record<string, unknown>)[item.key];
              const num = val ? parseFloat(val as string) : null;
              return (
                <div key={item.key} className="bg-cw-linen rounded p-3">
                  <div className="cw-label text-xs mb-1">{item.label}</div>
                  <div className="font-heading font-bold text-xl text-cw-black">
                    {num !== null ? Math.round(num) : '—'}
                  </div>
                  <div className="cw-label text-xs text-cw-stone">{item.weight}</div>
                  {num !== null && (
                    <div className="mt-2 h-1 bg-cw-mist rounded overflow-hidden">
                      <div className={`h-full ${item.color} rounded`} style={{ width: `${num}%` }} />
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Coaching narrative */}
      {member.coaching_narrative && (
        <div>
          <div className="cw-label mb-2">The Selector's assessment</div>
          <div className="bg-cw-linen rounded p-4 border-l-4 border-cw-coral">
            <p className="font-serif italic text-sm text-cw-black leading-relaxed">
              {member.coaching_narrative}
            </p>
          </div>
        </div>
      )}

      {!member.coaching_narrative && (
        <div className="bg-cw-linen rounded p-4 text-center">
          <p className="font-body text-sm text-cw-stone">
            The Selector's coaching narrative will appear here after the weekly assessment is completed by The Coach.
          </p>
        </div>
      )}
    </div>
  );
}
