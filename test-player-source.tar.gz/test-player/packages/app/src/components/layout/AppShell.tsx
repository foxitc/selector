import React, { useState } from 'react';
import { NavLink, Outlet, useNavigate } from 'react-router-dom';
import { Users, Trophy, ClipboardList, BarChart3, Plug, Tv, Settings, LogOut, Menu, X } from 'lucide-react';
import { useAuth } from '../../hooks/useAuth';
import { clearToken } from '../../lib/api';

const navItems = [
  { label: 'Squad',       to: '/squad',      icon: <Users className="w-4 h-4" /> },
  { label: 'Scores',      to: '/scores',     icon: <Trophy className="w-4 h-4" /> },
  { label: 'Assessment',  to: '/assessment', icon: <ClipboardList className="w-4 h-4" /> },
  { label: 'Reports',     to: '/reports',    icon: <BarChart3 className="w-4 h-4" /> },
  { label: 'Displays',    to: '/displays',   icon: <Tv className="w-4 h-4" /> },
  { label: 'Connectors',  to: '/connectors', icon: <Plug className="w-4 h-4" /> },
  { label: 'Settings',    to: '/settings',   icon: <Settings className="w-4 h-4" /> },
];

export function AppShell() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [mobileOpen, setMobileOpen] = useState(false);

  const handleLogout = () => {
    clearToken();
    logout();
    navigate('/login');
  };

  return (
    <div className="flex h-screen overflow-hidden bg-cw-linen">
      {/* Sidebar — desktop */}
      <aside className="hidden lg:flex w-52 bg-cw-black flex-col flex-shrink-0">
        <Sidebar user={user} onLogout={handleLogout} />
      </aside>

      {/* Mobile sidebar */}
      {mobileOpen && (
        <div className="lg:hidden fixed inset-0 z-50 flex">
          <div className="absolute inset-0 bg-black/60" onClick={() => setMobileOpen(false)} />
          <aside className="relative w-52 bg-cw-black flex flex-col">
            <button className="absolute top-4 right-4 text-cw-stone hover:text-white" onClick={() => setMobileOpen(false)}>
              <X className="w-5 h-5" />
            </button>
            <Sidebar user={user} onLogout={handleLogout} />
          </aside>
        </div>
      )}

      {/* Main */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Mobile topbar */}
        <header className="lg:hidden flex items-center gap-3 px-4 py-3 bg-cw-black border-b border-cw-stone/20">
          <button onClick={() => setMobileOpen(true)} className="text-cw-stone hover:text-white">
            <Menu className="w-5 h-5" />
          </button>
          <span className="font-heading font-bold tracking-wider text-sm text-white uppercase">Test Player</span>
        </header>

        <main className="flex-1 overflow-y-auto scrollbar-thin">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
            <Outlet />
          </div>
        </main>
      </div>
    </div>
  );
}

function Sidebar({ user, onLogout }: { user: { firstName?: string; lastName?: string; role?: string } | null; onLogout: () => void }) {
  return (
    <>
      {/* Logo */}
      <div className="px-4 pt-5 pb-4 border-b border-white/10">
        <div className="font-heading text-xs font-semibold tracking-widest uppercase text-cw-coral mb-1">
          Cat &amp; Wickets
        </div>
        <div className="font-serif italic text-white text-lg leading-tight">Test Player</div>
        <div className="font-heading text-xs tracking-wider uppercase text-cw-stone mt-0.5">
          Powered by The Selector
        </div>
      </div>

      {/* Nav */}
      <nav className="flex-1 px-3 py-3 space-y-0.5">
        {navItems.map(item => (
          <NavLink
            key={item.to}
            to={item.to}
            className={({ isActive }) =>
              `flex items-center gap-3 px-3 py-2 rounded font-heading font-semibold text-xs tracking-wider uppercase transition-colors
              ${isActive
                ? 'bg-cw-coral text-white'
                : 'text-cw-stone hover:text-white hover:bg-white/5'
              }`
            }
          >
            {item.icon}
            {item.label}
          </NavLink>
        ))}
      </nav>

      {/* User */}
      <div className="border-t border-white/10 p-3">
        <div className="flex items-center gap-2 px-2 py-1.5">
          <div className="w-7 h-7 rounded-full bg-cw-coral flex items-center justify-center flex-shrink-0">
            <span className="font-heading font-bold text-xs text-white">
              {user?.firstName?.[0]}{user?.lastName?.[0]}
            </span>
          </div>
          <div className="flex-1 min-w-0">
            <p className="font-heading font-semibold text-xs text-white tracking-wide truncate">
              {user?.firstName} {user?.lastName}
            </p>
            <p className="font-heading text-xs text-cw-stone uppercase tracking-wider truncate">
              {user?.role === 'admin' ? 'Admin' : 'The Coach'}
            </p>
          </div>
          <button onClick={onLogout} title="Log out" className="p-1 text-cw-stone hover:text-cw-coral transition-colors">
            <LogOut className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </>
  );
}
