import React from 'react';
import { Loader2, X, ChevronUp, ChevronDown, Minus } from 'lucide-react';
import { TIER_LABELS, TIER_CLASSES, STATUS_LABELS, STATUS_CLASSES } from '../../hooks/useAuth';

// ------------------------------------------------------------------
// BUTTON
// ------------------------------------------------------------------
interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'ghost' | 'danger';
  size?: 'sm' | 'md' | 'lg';
  loading?: boolean;
  icon?: React.ReactNode;
}

export function Button({ variant = 'secondary', size = 'md', loading, icon, children, className = '', disabled, ...props }: ButtonProps) {
  const base = 'inline-flex items-center justify-center gap-2 font-heading font-semibold tracking-wider uppercase transition-all active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed rounded';
  const variants = {
    primary:   'bg-cw-coral text-white hover:bg-red-500',
    secondary: 'bg-transparent text-cw-black border border-cw-sand hover:bg-cw-linen',
    ghost:     'bg-transparent text-cw-stone hover:text-cw-black hover:bg-cw-linen',
    danger:    'bg-red-500 text-white hover:bg-red-600',
  };
  const sizes = { sm: 'h-7 px-3 text-xs', md: 'h-9 px-4 text-sm', lg: 'h-11 px-6 text-base' };

  return (
    <button className={`${base} ${variants[variant]} ${sizes[size]} ${className}`} disabled={disabled || loading} {...props}>
      {loading ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : icon}
      {children}
    </button>
  );
}

// ------------------------------------------------------------------
// INPUT
// ------------------------------------------------------------------
interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  error?: string;
  hint?: string;
}

export function Input({ label, error, hint, id, className = '', ...props }: InputProps) {
  const inputId = id ?? label?.toLowerCase().replace(/\s+/g, '-');
  return (
    <div className="space-y-1">
      {label && <label htmlFor={inputId} className="cw-label block">{label}</label>}
      <input
        id={inputId}
        className={`w-full h-9 px-3 text-sm border rounded bg-white font-body
          ${error ? 'border-cw-coral focus:ring-cw-coral' : 'border-cw-mist focus:border-cw-sand'}
          focus:outline-none focus:ring-1 ${className}`}
        {...props}
      />
      {error && <p className="text-xs text-cw-coral font-body">{error}</p>}
      {hint && !error && <p className="text-xs text-cw-stone font-body">{hint}</p>}
    </div>
  );
}

// ------------------------------------------------------------------
// TEXTAREA
// ------------------------------------------------------------------
interface TextareaProps extends React.TextareaHTMLAttributes<HTMLTextAreaElement> {
  label?: string;
  hint?: string;
}

export function Textarea({ label, hint, id, className = '', ...props }: TextareaProps) {
  const taId = id ?? label?.toLowerCase().replace(/\s+/g, '-');
  return (
    <div className="space-y-1">
      {label && <label htmlFor={taId} className="cw-label block">{label}</label>}
      <textarea
        id={taId}
        className={`w-full px-3 py-2 text-sm border border-cw-mist rounded bg-white font-body
          focus:outline-none focus:ring-1 focus:border-cw-sand resize-none ${className}`}
        {...props}
      />
      {hint && <p className="text-xs text-cw-stone font-body">{hint}</p>}
    </div>
  );
}

// ------------------------------------------------------------------
// SCORE STARS (1-5 rating)
// ------------------------------------------------------------------
interface StarRatingProps {
  value: number;
  onChange?: (v: number) => void;
  label?: string;
  readonly?: boolean;
}

export function StarRating({ value, onChange, label, readonly = false }: StarRatingProps) {
  return (
    <div className="space-y-1">
      {label && <div className="cw-label">{label}</div>}
      <div className="flex gap-1">
        {[1, 2, 3, 4, 5].map(n => (
          <button
            key={n}
            type="button"
            onClick={() => !readonly && onChange?.(n)}
            disabled={readonly}
            className={`w-8 h-8 rounded text-sm font-heading font-bold transition-all
              ${n <= value
                ? 'bg-cw-coral text-white'
                : 'bg-cw-mist text-cw-stone hover:bg-cw-sand hover:text-white'
              } ${readonly ? 'cursor-default' : 'cursor-pointer active:scale-90'}`}
          >
            {n}
          </button>
        ))}
      </div>
    </div>
  );
}

// ------------------------------------------------------------------
// TIER BADGE
// ------------------------------------------------------------------
export function TierBadge({ tier, size = 'md' }: { tier: string; size?: 'sm' | 'md' }) {
  const cls = TIER_CLASSES[tier] ?? 'bg-cw-stone text-white';
  const label = TIER_LABELS[tier] ?? tier;
  const sz = size === 'sm' ? 'px-2 py-0.5 text-xs' : 'px-3 py-1 text-xs';
  return (
    <span className={`${cls} ${sz} font-heading font-bold tracking-wider uppercase rounded inline-block`}>
      {label}
    </span>
  );
}

// ------------------------------------------------------------------
// STATUS BADGE
// ------------------------------------------------------------------
export function StatusBadge({ status }: { status: string }) {
  const cls = STATUS_CLASSES[status] ?? 'bg-cw-stone text-white';
  const label = STATUS_LABELS[status] ?? status;
  return (
    <span className={`${cls} px-2 py-0.5 text-xs font-heading font-bold tracking-wider uppercase rounded inline-block`}>
      {label}
    </span>
  );
}

// ------------------------------------------------------------------
// SCORE CHANGE INDICATOR
// ------------------------------------------------------------------
export function ScoreChange({ change }: { change: number | null }) {
  if (change === null || change === undefined) return null;
  if (Math.abs(change) < 0.1) return <Minus className="w-3 h-3 text-cw-stone inline" />;
  return change > 0
    ? <span className="text-cw-sage font-heading font-bold text-xs flex items-center gap-0.5"><ChevronUp className="w-3 h-3" />+{change.toFixed(1)}</span>
    : <span className="text-cw-coral font-heading font-bold text-xs flex items-center gap-0.5"><ChevronDown className="w-3 h-3" />{change.toFixed(1)}</span>;
}

// ------------------------------------------------------------------
// AVATAR
// ------------------------------------------------------------------
export function Avatar({ initials, color, size = 'md' }: { initials: string; color: string; size?: 'sm' | 'md' | 'lg' }) {
  const sizes = { sm: 'w-7 h-7 text-xs', md: 'w-9 h-9 text-sm', lg: 'w-12 h-12 text-base' };
  return (
    <div className={`${sizes[size]} rounded-full flex items-center justify-center font-heading font-bold text-white flex-shrink-0`}
      style={{ background: color }}>
      {initials}
    </div>
  );
}

// ------------------------------------------------------------------
// CARD
// ------------------------------------------------------------------
export function Card({ children, className = '', padding = 'md' }: {
  children: React.ReactNode; className?: string; padding?: 'none' | 'sm' | 'md' | 'lg';
}) {
  const p = { none: '', sm: 'p-3', md: 'p-5', lg: 'p-6' }[padding];
  return <div className={`cw-card ${p} ${className}`}>{children}</div>;
}

// ------------------------------------------------------------------
// PAGE HEADER
// ------------------------------------------------------------------
export function PageHeader({ title, subtitle, action }: {
  title: string; subtitle?: string; action?: React.ReactNode;
}) {
  return (
    <div className="flex items-start justify-between mb-6">
      <div>
        <h1 className="font-heading font-bold text-2xl tracking-wide uppercase text-cw-black">{title}</h1>
        {subtitle && <p className="font-serif italic text-cw-stone text-sm mt-0.5">{subtitle}</p>}
      </div>
      {action && <div className="flex-shrink-0 ml-4">{action}</div>}
    </div>
  );
}

// ------------------------------------------------------------------
// EMPTY STATE
// ------------------------------------------------------------------
export function EmptyState({ icon, title, description, action }: {
  icon: React.ReactNode; title: string; description?: string; action?: React.ReactNode;
}) {
  return (
    <div className="flex flex-col items-center justify-center py-16 text-center">
      <div className="p-4 rounded-full bg-cw-linen text-cw-stone mb-4">{icon}</div>
      <p className="font-heading font-bold text-sm uppercase tracking-wider text-cw-black">{title}</p>
      {description && <p className="font-body text-sm text-cw-stone mt-1 max-w-xs">{description}</p>}
      {action && <div className="mt-4">{action}</div>}
    </div>
  );
}

// ------------------------------------------------------------------
// SPINNER
// ------------------------------------------------------------------
export function Spinner({ className = 'w-5 h-5' }: { className?: string }) {
  return <Loader2 className={`${className} animate-spin text-cw-coral`} />;
}

// ------------------------------------------------------------------
// MODAL
// ------------------------------------------------------------------
export function Modal({ open, onClose, title, subtitle, children, maxWidth = 'md' }: {
  open: boolean; onClose: () => void; title: string; subtitle?: string;
  children: React.ReactNode; maxWidth?: 'sm' | 'md' | 'lg' | 'xl';
}) {
  React.useEffect(() => {
    const h = (e: KeyboardEvent) => { if (e.key === 'Escape') onClose(); };
    if (open) document.addEventListener('keydown', h);
    return () => document.removeEventListener('keydown', h);
  }, [open, onClose]);

  if (!open) return null;
  const widths = { sm: 'max-w-sm', md: 'max-w-md', lg: 'max-w-lg', xl: 'max-w-2xl' };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-cw-black/60" onClick={onClose} />
      <div className={`relative bg-white rounded-lg shadow-2xl w-full ${widths[maxWidth]} max-h-[90vh] flex flex-col`}>
        <div className="flex items-start justify-between px-5 py-4 border-b border-cw-mist bg-cw-black rounded-t-lg">
          <div>
            <h2 className="font-heading font-bold text-sm tracking-wider uppercase text-white">{title}</h2>
            {subtitle && <p className="font-serif italic text-cw-stone text-xs mt-0.5">{subtitle}</p>}
          </div>
          <button onClick={onClose} className="ml-4 p-1 text-cw-stone hover:text-white transition-colors">
            <X className="w-4 h-4" />
          </button>
        </div>
        <div className="overflow-y-auto flex-1 p-5 scrollbar-thin">{children}</div>
      </div>
    </div>
  );
}
