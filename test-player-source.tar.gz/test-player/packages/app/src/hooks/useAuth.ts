import { create } from 'zustand';
import { persist } from 'zustand/middleware';

interface User {
  id: string;
  email: string;
  firstName: string;
  lastName: string;
  role: 'admin' | 'coach' | 'viewer';
  venueId: string | null;
}

interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  setUser: (u: User) => void;
  logout: () => void;
}

export const useAuth = create<AuthState>()(
  persist(
    (set) => ({
      user: null,
      isAuthenticated: false,
      setUser: (user) => set({ user, isAuthenticated: true }),
      logout: () => set({ user: null, isAuthenticated: false }),
    }),
    { name: 'tp-auth' },
  ),
);

// Tier display helpers
export const TIER_LABELS: Record<string, string> = {
  'could-say':  'Could Say',
  'should-say': 'Should Say',
  'have-to':    'Have To',
  'review':     'Review',
};

export const TIER_CLASSES: Record<string, string> = {
  'could-say':  'tier-could',
  'should-say': 'tier-should',
  'have-to':    'tier-hasto',
  'review':     'tier-review',
};

export const STATUS_LABELS: Record<string, string> = {
  'on-programme':  'On programme',
  'under-review':  'Under review',
  'not-yet':       'Not yet',
};

export const STATUS_CLASSES: Record<string, string> = {
  'on-programme':  'status-on',
  'under-review':  'status-review',
  'not-yet':       'status-not-yet',
};

// Current week ending (Sunday)
export function currentWeek(): string {
  const today = new Date();
  const day = today.getDay();
  const sunday = new Date(today);
  sunday.setDate(today.getDate() - (day === 0 ? 0 : day));
  return sunday.toISOString().split('T')[0]!;
}

export function formatWeek(dateStr: string): string {
  return new Date(dateStr).toLocaleDateString('en-GB', {
    day: 'numeric', month: 'long', year: 'numeric',
  });
}
