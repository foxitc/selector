import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  server: {
    port: 3101,
    proxy: { '/api': { target: 'http://localhost:3100', changeOrigin: true } },
  },
  build: { outDir: 'dist', sourcemap: false },
});
