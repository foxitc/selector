/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        // Cat & Wickets brand palette
        cw: {
          linen:  '#f5e5cf',
          sand:   '#e5ba96',
          coral:  '#fd6f53',
          black:  '#1c1c1c',
          sage:   '#6e9277',
          mist:   '#e0e6e9',
          stone:  '#a8a28a',
          tan:    '#b38b6d',
          cream:  '#fff5d6',
          slate:  '#9db3c1',
        },
      },
      fontFamily: {
        heading: ['"Barlow Condensed"', 'sans-serif'],
        body:    ['"Barlow Condensed"', 'sans-serif'],
        serif:   ['"Playfair Display"', 'Georgia', 'serif'],
        mono:    ['"JetBrains Mono"', 'monospace'],
      },
    },
  },
  plugins: [],
};
